package com.itc.rms.services;
/**
 * Akash Garg 20628
 */
import java.util.List;

import org.springframework.stereotype.Service;

import com.itc.rms.entities.Graph;

@Service
public interface GenerateGraphServices {
	/**
	 * @return Get all value from database for plotting Total sales vs months graph
	 */
	public abstract List<Graph> getAllValueForGraph();
}
