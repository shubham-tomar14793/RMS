package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.Category;


/**
 * 
 * @author Abhishek Singh
 *
 */
public interface CategoryServices {
	/**
	 * method to add category
	 * @param category
	 * @return
	 */
	public abstract boolean addCategory(Category category);
	/**
	 * method to remove category
	 * @param category
	 * @return
	 */
	public abstract boolean removeCategory(Category category);
	/**
	 * method to edit category
	 * @param category
	 * @return
	 */
	public abstract boolean editCategory(Category category);
	/**
	 * method to view category
	 * @return
	 */
	public abstract List<Category> viewCategory();
}
