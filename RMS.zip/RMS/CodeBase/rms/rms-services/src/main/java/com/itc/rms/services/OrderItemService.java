package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.OrderItem;

public interface OrderItemService {
	
	/**
	 *@return list of order items
	 */
public abstract List<OrderItem> getOrderItem();
/**
 * @return order item based on order_Id
 */
 public abstract OrderItem getOrderItem(Long order_Id);
 
 /**
  * 
  * @param order
  * @return to add order item
  */
 public abstract boolean addOrderItem(OrderItem orderItem);

 /**
  * 
  * @param order
  * @return to remove order item
  */
 
 public abstract boolean removeOrderItem(OrderItem orderItem);
}
