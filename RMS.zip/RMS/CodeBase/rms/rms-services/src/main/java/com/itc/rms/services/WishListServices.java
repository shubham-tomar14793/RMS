package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.RetailerProduct;

public interface WishListServices  {
	
	
	/**
	 * Method to get wishlist of a user based on his userId
	 * @param UserId
	 * @return
	 */
	List<RetailerProduct> getWishListByUserId(long userId);
	
	/**
	 * Method to add retailer product to a user's wishlist
	 * @param retailerProduct
	 * @param UserId
	 * @return
	 */
	boolean addRetailerProduct(RetailerProduct retailerProduct, long userId);
	
	/**
	 * Method to  remove retailer product from a user's wishlist
	 * @param retailerProduct
	 * @param UserId
	 * @return
	 */
	boolean removeRetailerProduct(RetailerProduct retailerProduct, long userId);

}
