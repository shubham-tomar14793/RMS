package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.Order;
import com.itc.rms.entities.Payment;

/**
 * 
 * @author Debolina
 *
 */

public interface PaymentServices {
	
public abstract boolean addPaymentDetails(Payment payment);
	
	/**
	 * Method to get list of payment details
	 * @return List<Payment>
	 */
	public abstract List<Payment> getPaymentDetails();
	
	/**
	 * Method to get a particular payment detail by order
	 * @param order
	 * @return
	 */
	
	public abstract Payment getPaymentDetailsByOrder(Order order);

	

}
