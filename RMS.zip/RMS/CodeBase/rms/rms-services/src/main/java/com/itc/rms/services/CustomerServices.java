package com.itc.rms.services;


import com.itc.rms.entities.Customer;
import com.itc.rms.entities.User;

/**
 * 
 * @author swati,Saikat Dey Sarkar
 *
 */
public interface CustomerServices {
	
	public abstract boolean setCustomerDetails(Customer customer);
	
	public abstract Customer getCustomer(long customerId );

	public abstract User getCustomerByEmailId(String sessionEmailId);
}
