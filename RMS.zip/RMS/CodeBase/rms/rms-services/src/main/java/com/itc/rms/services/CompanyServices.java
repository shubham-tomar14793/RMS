package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.Company;

public interface CompanyServices {

	/**
	 * Method to get add company
	 * 
	 * @param company
	 * @return
	 */
	public abstract boolean addCompany(Company company);

	/**
	 * Method to get remove company
	 * 
	 * @param company
	 * @return
	 */
	public abstract boolean removeCompany(Company company);

	/**
	 * Method to get edit company
	 * 
	 * @param company
	 * @return
	 */
	public abstract boolean editCompany(Company company);

	/**
	 * Method to view company
	 * 
	 * @return
	 */
	public abstract List<Company> getAllCompany();

}
