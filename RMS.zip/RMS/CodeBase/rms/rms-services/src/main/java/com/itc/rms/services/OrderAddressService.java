package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.OrderAddress;

public interface OrderAddressService {
	
	/**
	 * 
	 * 
	 * @param orderAddress
	 * @return order address of the customer
	 */
  public abstract boolean  addOrderAddress(OrderAddress orderAddress);
  /**
   * 
   * @param order_Address_Id
   * @return get the order address
   */
  public abstract OrderAddress getOrderAddress(Long order_Address_Id);
  /**
   * 
   * @return list of order addresses
   */
  public abstract List<OrderAddress> getOrderAddress();

}
