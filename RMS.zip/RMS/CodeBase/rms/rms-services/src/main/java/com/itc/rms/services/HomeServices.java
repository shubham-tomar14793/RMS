package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.RetailerProduct;

/**
 * 
 * @author shubham
 *
 */

public interface HomeServices {
     
	List<RetailerProduct> getAllRetailerProduct();
}
