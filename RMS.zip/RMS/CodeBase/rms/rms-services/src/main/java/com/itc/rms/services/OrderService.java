package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.Order;


/**
 * @author Mohit Juthani
 * @author Akash Jothish
 * @author Arnab Datta
 *
 */
public interface OrderService {
	
	public abstract List<Order> getAllOrders();
	
	public abstract Order getOrderById(long orderId);
	
	public abstract List<Order> getAllOrdersByUserId(long userId);

	/**
	 * 
	 * @param order object
	 * @return Adding order to backend
	 */
	public abstract boolean addOrder(Order order);
	
	/**
	 * 
	 * @param order object
	 * @return remove order
	 */
	public abstract boolean removeOrder(Order order);

}
