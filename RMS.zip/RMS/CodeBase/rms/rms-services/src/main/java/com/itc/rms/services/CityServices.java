package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.City;

public interface CityServices {
	boolean addCity(City city);
	List<City> getAllCity();

}
