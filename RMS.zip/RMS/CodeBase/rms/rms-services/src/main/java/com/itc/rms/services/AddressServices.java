/**
 * Author:Ranjitha
 */



package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.Address;


public interface AddressServices {

	public  List<Address> getAllAddress(long userId);
	public boolean addAddress(Address address,long userId);
	public boolean editAddress(Address address);
	public boolean deleteAddress(Address address);
}
