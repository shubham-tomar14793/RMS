/*
 * @Author :  Prasoon Mehta
 */


package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.Retailer;


public interface RetailerServices {
	
	public abstract boolean addRetailer(Retailer retailer);
	public abstract boolean removeRetailer(Retailer retailer);
	public abstract boolean editRetailer(Retailer retailer);
	public abstract List<Retailer> viewAllRetailer();
	

}
