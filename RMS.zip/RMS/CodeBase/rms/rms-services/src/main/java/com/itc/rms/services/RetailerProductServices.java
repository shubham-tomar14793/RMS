package com.itc.rms.services;

import java.util.List;

import com.itc.rms.entities.Product;
import com.itc.rms.entities.RetailerProduct;

public interface RetailerProductServices {
	
	public abstract List<RetailerProduct> getAllProducts();
}
