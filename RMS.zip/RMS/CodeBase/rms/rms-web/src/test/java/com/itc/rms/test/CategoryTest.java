package com.itc.rms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.itc.rms.controllers.CategoryController;
import com.itc.rms.entities.Category;

public class CategoryTest {

	
	CategoryController categoryController = new CategoryController();
	
	@Test
	public void testAddCategory() {
		Category category = new Category();
		category.setCategoryName("TestCategory123");
	//	assertTrue(categoryController.addCategory(category));
	}
	
	@Test
	public void testGetAllCategory() {
		assertNotNull(categoryController.viewCategory());
	}


}
