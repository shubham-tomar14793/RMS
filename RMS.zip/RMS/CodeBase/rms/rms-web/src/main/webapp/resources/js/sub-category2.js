/**
 * 
 */
$(document).ready(function() {
var id=0;
	$.ajax({
		url : "getAllSubCategories",
		method : "GET",
		success : function(subCategories) {
			subCategories = $.parseJSON(subCategories);
			var str="";
			$.each(subCategories,function(index,subCategory){
					var subid=subCategory.category.categoryId;
					
					if(subid!=id){
					
				 str+="<div class=\"panel panel-default\"><div class=\"panel-heading\">";
			     str+="<h4 class=\"panel-title\">";
				 str+="<a data-toggle=\"collapse\" data-parent=\"#accordian\" href=\"#sportswear\">";
				 str+="<span class=\"badge pull-right\"><i class=\"fa fa-plus\"></i></span>";
				 subCategory.category.category_name
				 str+="</a></h4></div>";
				 $.each(subCategories,function(index,subCategory){
					if(subCategory.category.categoryId==subid){
				 str+="<div id=\"sportswear\" class=\"panel-collapse collapse\">";
				str+="<div class=\"panel-body\">";
				str+="<ul><li><a href=\"#\">"+subCategory.subCategoryName +"</a></li>	</ul></div></div>";
					}
					 id=subCategory.category.categoryId;
				 });
					
				
					}	
				
			});
			str+="</div>";
			$('#categories_id').html(str);
		  }
		});
});