/**
 * 
 */
var cart = [];
var count = 0;
var str;
$(document).ready(function() {

	if (localStorage.getItem('cartItems') != null) {

		console.log(localStorage.getItem('cartItems').split(','));
		str = localStorage.getItem('cartItems').split(',');
		$('#cart_count').html(str.length);
		cart.push(str);
		count = str.length;

	}

	$('#feature_item_content').delegate(".add-to-cart","click",storeInCart);
	function storeInCart() {
		attrName = $(this).attr("id");
		cart.push(attrName);
		localStorage.setItem('cartItems', cart);
		count++;
		$('#cart_count').html(count);

	}
});