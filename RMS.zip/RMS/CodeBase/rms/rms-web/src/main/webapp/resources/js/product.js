/**
 * 
 */
$(document).ready(function() {

	$.ajax({
		url : "getAllRetailerProducts",
		method : "GET",
		success : function(products) {
			products = $.parseJSON(products);
			var count = 0;
			$.each(products,function(index,product){
				console.log(product);
				$("#features_items_div").append("<div class='col-sm-4'>"+
							"<div class='product-image-wrapper'>"+
								"<div class='single-products'>"+
										"<div class='productinfo text-center'>"+
										"	<img src='"+product.product.imagePath+"' alt='' />"+
										"	<h2>"+product.price+" $</h2>"+
										"	<p>"+product.product.productName+"</p>"+
										"	<a href='#' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"+
										"</div>"+
										"<div class='product-overlay'>"+
										"	<div class='overlay-content'>"+
										"		<h2>"+product.price+" $"+
										"		<p>"+product.product.productName+"</p>"+
										"		<a href='#' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"+
										"	</div>"+
										"</div>"+
								"</div>"+
								"<div class='choose'>"+
									"<ul class='nav nav-pills nav-justified'>"+
										"<li><a href='#'><i class='fa fa-plus-square'></i>Add to wishlist</a></li>"+
										"<li><a href='#'><i class='fa fa-plus-square'></i>Add to compare</a></li>"+
									"</ul>"+
								"</div>"+
							"</div>"+
						"</div>");
			
				if(product.product.category.categoryName == "JUICE")
				$("#juice").append("<div class='col-sm-3'>"+
						"<div class='product-image-wrapper'>"+
							"<div class='single-products'>"+
								"<div class='productinfo text-center'>"+
									"<img src='"+product.product.imagePath+"' alt='' />"+
									"<h2>"+product.price+" $</h2>"+
									"<p>"+product.product.productName+"</p>"+
									"<a href='#' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"+
								"</div>"+
								
							"</div>"+
						"</div>"+
						"</div>");
				
				if(product.product.category.categoryName == "KITCHEN")
				$("#kitchen").append("<div class='col-sm-3'>"+
						"<div class='product-image-wrapper'>"+
							"<div class='single-products'>"+
								"<div class='productinfo text-center'>"+
									"<img src='"+product.product.imagePath+"' alt='' />"+
									"<h2>"+product.price+" $</h2>"+
									"<p>"+product.product.productName+"</p>"+
									"<a href='#' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"+
								"</div>"+
								
							"</div>"+
						"</div>"+
						"</div>");
				
				if(count++<3)
				$("#active_items").append("<div class='col-sm-4'>"+
						"<div class='product-image-wrapper'>"+
							"<div class='single-products'>"+
								"<div class='productinfo text-center'>"+
									"<img src='"+product.product.imagePath+"' alt='' />"+
									"<h2>"+product.price+" $</h2>"+
									"<p>"+product.product.productName+"</p>"+
									"<a href='#' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"+
								"</div>"+
							"</div>"+
						"</div>"+
						"</div>");
				else if(count<7)
				$("#inactive_items").append("<div class='col-sm-4'>"+
						"<div class='product-image-wrapper'>"+
						"<div class='single-products'>"+
							"<div class='productinfo text-center'>"+
								"<img src='"+product.product.imagePath+"' alt='' />"+
								"<h2>"+product.price+" $</h2>"+
								"<p>"+product.product.productName+"</p>"+
								"<a href='#' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"+
							"</div>"+
						"</div>"+
					"</div>"+
					"</div>");
			
			});
				
				
			
			
		}

	});
});




