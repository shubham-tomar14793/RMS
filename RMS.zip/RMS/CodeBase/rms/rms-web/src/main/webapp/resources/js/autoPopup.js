/**
 * Created by shubham on 8/10/15.
 */

$(document).ready(function(){
    $('#myModal').modal('show');
    $('.cityName a').click(function(){
         var locationButtonName=this.text;
        $('#locationCityName').val(locationButtonName);
         setHeaderCityName(locationButtonName)
    });

});

function setHeaderCityName(cityName){
    //alert('acasc');
    $('#headerCityName').text(cityName);
}
