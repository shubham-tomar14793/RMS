/**
 * 
 */
$(document).ready(
		function() {
			$.ajax({
				url : "getAllCategories",
				method : "GET",
				success : function(categories) {
					categories = $.parseJSON(categories);
					$.each(categories, function(index, category) {

						$("#categoriesTab").append(
								'<li id="'+category.categoryId+'"><a href="#categoryTab' + category.categoryId
										+ '" data-toggle="tab">'
										+ category.categoryName + '</a></li>');

						if (index == 0)
							$("#"+category.categoryId).addClass("active");
					});
				}
			});
		});
