/**
 * 
 */
$(document).ready(function() {

	$.ajax({
		url : "getAllSubCategories",
		method : "GET",
		success : function(subCategories) {
			subCategories = $.parseJSON(subCategories);
			
			$("#categories_id").append("<div class='panel panel-default'>"+
			"<div class='panel-heading'>"+
				"<h4 class='panel-title'>"+
					"<a data-toggle='collapse' data-parent='#accordian' href='#sportswear'>"+
						"<span class='badge pull-right'><i class='fa fa-plus'></i></span>"+
						"All Sub Categories"+
					"</a>"+
				"</h4>"+
			"</div>" +
			"<div id='sportswear' class='panel-collapse collapse'>"+
									"<div class='panel-body'>"+
										"<ul>");
			
			$.each(subCategories,function(index,subCategory){
				console.log(subCategory);
				$("#categories_id").append("<li><a href='#'>"+subCategory.subCategoryName+" </a></li>");
			});
			
			$("#categories_id").append("</ul>"+
										"</div>"+
									"</div>"+
								"</div>");
		}
	});
});