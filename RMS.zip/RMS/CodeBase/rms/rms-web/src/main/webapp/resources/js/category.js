/**
 * 
 */
$(document).ready(function() {

	$.ajax({
		url : "getAllCategories",
		method : "GET",
		success : function(categories) {
			categories = $.parseJSON(categories);
			$.each(categories,function(index,category){
				console.log(category);
				//$("#features_items_div").append("<div class='col-sm-4'>");
			});
		}
	});
});