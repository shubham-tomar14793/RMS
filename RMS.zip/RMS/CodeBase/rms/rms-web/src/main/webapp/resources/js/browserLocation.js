  var geocoder;

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(successFunction, errorFunction);
}
//Get the latitude and the longitude;
function successFunction(position) {
    var lat = position.coords.latitude;
    var lng = position.coords.longitude;
    codeLatLng(lat, lng)
}

function errorFunction(){
    alert("Geocoder failed");
}
function initialize() {
    geocoder = new google.maps.Geocoder();
  }
  function codeLatLng(lat, lng) {
    var latlng = new google.maps.LatLng(lat, lng);
    geocoder.geocode({'latLng': latlng}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        if (results[1]) {
         //formatted address
            console.log(results[3]);
            //alert(results[3].address_components[2].long_name);
            $(function(){
                $('#locationCityName').attr("placeholder","Current City : "+results[3].address_components[2].long_name);
            });

        } else {
          alert("No results found");
        }
      }else {
        alert("Geocoder failed due to: " + status);
      }
    });
}
