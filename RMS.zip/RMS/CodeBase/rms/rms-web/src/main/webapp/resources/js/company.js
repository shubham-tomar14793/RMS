/**
 * 
 */
$(document).ready(function() {
	$.ajax({
		url : "getAllCompany",
		method : "GET",
		success : function(companies) {
			companies = $.parseJSON(companies);
			$.each(companies,function(index,company){
				console.log(company);
				$("#companies").append('<li id="'+company.companyName+'"class="companyProduct">'+company.companyName+'</li>');
				
				//for qunatity use this line
			//<li><a href="#"> <span class="pull-right">(50)</span>Acne</a></li>
			});
		},async : false
	});
	
	
	$('ul').delegate(".companyProduct","click",companyProducts);
});