/**
 * 
 */




function del_row(row) {
	
	
    var i=row.parentNode.parentNode.rowIndex;
    var records = document.getElementById('table1').rows;
    var del_val=records[i].cells[3].childNodes[0].value;
    var total=Add();
    var total_new=total-del_val;
    document.getElementById("amt").value = total_new;
    document.getElementById('table1').deleteRow(i);
    
  /*  for(var j=i+1;j<=records.length;j++)
    	{
    	   records[i]=records[j];
    	 
    	}
    records.length--;
    */
    
    
    
}


function onlyNumbers(evt) {
         var e = event || evt; // for trans-browser compatibility
         var charCode = e.which || e.keyCode;

         if (charCode > 31 && (charCode < 48 || charCode > 57))
             return false;
         return true;
     }


   function Add() {
	   var total;
         var a, b, c, d;
         a = parseInt(document.getElementById("price1").value);


 if (isNaN(a) == true) {
         a = 0;
     }
     var b = parseInt(document.getElementById("price2").value);
     if (isNaN(b) == true) {
         b = 0;
     }
     var c = parseInt(document.getElementById("price3").value);
     if (isNaN(c) == true) {
         c = 0;
     }
     total=a+b+c;
     document.getElementById("amt").value = total;
     return total;
}

   
   
   
   function mul() {
	   
   var records = document.getElementById('table1').rows;

   for (var i = 2; i < records.length; i++) 
   {
	   var qty = records[i].cells[1].childNodes[0].value;
	 
	   var price = records[i].cells[2].childNodes[0].value;

	   var answer = (Number(qty) * Number(price)).toFixed(2);
	  
	   records[i].cells[3].childNodes[0].value = answer;
	 
	}
   
   }
   
  
   
   
   
   
/* $("#qty1,#rate1").keyup(function () {
    	    $('#price1').val($('#qty1').val() * $('#rate1').val());
    	}); */   