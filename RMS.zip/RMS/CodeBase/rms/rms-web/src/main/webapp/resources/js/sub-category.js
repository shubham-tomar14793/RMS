/*
 * 
 */
$(document).ready(function() {
var id=0;
var category=[];
	$.ajax({
		url : "getAllSubCategories",
		method : "GET",
		success : function(subCategories) {
			subCategories = $.parseJSON(subCategories);
			var str="";
			$.each(subCategories,function(index,subCategory){
			
					category.push(subCategory.category.categoryName);

					
			});
			
			var uniqueCategory=category.filter(function(itm,i,category){
				
				return i==category.indexOf(itm);
				
			});
			
			
		
			console.log(category);
			console.log(uniqueCategory);
			var str="";
			var i=0;
			$.each(uniqueCategory,function(index,categoryName){	
				i++;
				//alert(categoryName);
				str+='<div class="panel panel-default">';
				str+='<div class="panel-heading">';
				str+='<h4 class="panel-title">';
				str+='<a data-toggle="collapse" data-parent="#accordian" href="#category'+i+'">';
					str+='	<span class="badge pull-right"><i class="fa fa-plus"></i></span>';
					str+=	categoryName;
					str+='	</a>';
					str+='</h4>';
					str+='</div>';
					str+='<div id="category'+i+'" class="panel-collapse collapse">';
					str+='	<div class="panel-body">';
					str+='<ul>';
				$.each(subCategories,function(index,subCategory){
				
							if(subCategory.category.categoryName==categoryName){
							//	alert(subCategory.subCategoryName);
								
										str+='<li id="'+subCategory.subCategoryName+'" style="cursor:pointer;" class="accordionSubCategory">'+  subCategory.subCategoryName + '</li>';

						     }
							
							
						
				
		     });
				str+='</ul></div> </div>';
			});
			str+='</div>';
			$('#accordian').html(str);
			
			
		  },
		  async : false
		});
	
	$('ul').delegate(".accordionSubCategory","click",subCategory);
	
	
	
	
});