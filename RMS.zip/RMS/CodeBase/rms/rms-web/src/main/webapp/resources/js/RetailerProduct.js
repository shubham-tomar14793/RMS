/**
 * 
 */
$(document).ready(function() {
	
	retailerProductsJSON = null;
	$.ajax({
		url : 'getAllRetailerProducts',
		method : 'GET',
		success : function(retailerProducts) {
			retailerProducts = $.parseJSON(retailerProducts);
			retailerProductsJSON = retailerProducts;
			$.each(retailerProducts,function(index,retailerProduct){
				console.log(retailerProduct);
				$('#feature_item_content').append(""
						+"<div class='col-sm-4'>"
						+"<div class='product-image-wrapper'>"
							+"<div class='single-products'>"
								+"<div class='productinfo text-center'>"
										+"<img src='images/products/"+retailerProduct.imagePath+"' alt='' />"
												+"<h2>&#8377;"+ retailerProduct.price+"</h2>"
												+"<p>"+ retailerProduct.productName+"</p>"
											+"	<a  id='"+ retailerProduct.productId+"' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"
											+"</div>"
										+"<div class='product-overlay'>"
										+"<div class='overlay-content'>"
											+"<h2>&#8377;"+retailerProduct.price+"</h2>"
												+"<p>"+ retailerProduct.productName+"</p>"
												+"<a id='"+ retailerProduct.productId+"' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"
												+"</div>"
											+"</div>"
											+"</div>"
								+"<div class='choose'>"
								+"<ul class='nav nav-pills nav-justified'>"
									+"<li><a id='"+ retailerProduct.productId+"' href='#'>"+"<i class='fa fa-plus-square'>"+"</i>Add to wishlist</a></li>"
										+"</ul>"
									+"</div>"
								+"</div>"
						+"</div>");
			});
		},
		async : false
	});
});