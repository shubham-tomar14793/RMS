/**
 * 
 */

	




function subCategory(){
	
	subCategoryName = $(this).attr("id");
	
	var count=0;
	$.ajax({
		url : 'getAllRetailerProducts',
		method : 'GET',
		success : function(retailerProducts) {
			retailerProducts = $.parseJSON(retailerProducts);
			$('#feature_item_content').empty();
			$.each(retailerProducts,function(index,retailerProduct){
			if(retailerProduct.subCategory.subCategoryName==subCategoryName){
				console.log(retailerProduct);
				count++;
				$('#feature_item_content').append(""
						+"<div class='col-sm-4'>"
						+"<div class='product-image-wrapper'>"
							+"<div class='single-products'>"
								+"<div class='productinfo text-center'>"
										+"<img src='images/products/"+retailerProduct.imagePath+"' alt='' />"
												+"<h2>&#8377;"+ retailerProduct.price+"</h2>"
												+"<p>"+ retailerProduct.productName+"</p>"
											+"	<a  id='"+ retailerProduct.productId+"' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"
											+"</div>"
										+"<div class='product-overlay'>"
										+"<div class='overlay-content'>"
											+"<h2> &#8377;"+retailerProduct.price+"</h2>"
												+"<p>"+ retailerProduct.productName+"</p>"
												+"<a id='"+ retailerProduct.productId+"' class='btn btn-default add-to-cart'><i class='fa fa-shopping-cart'></i>Add to cart</a>"
												+"</div>"
											+"</div>"
											+"</div>"
								+"<div class='choose'>"
								+"<ul class='nav nav-pills nav-justified'>"
									+"<li><a id='"+ retailerProduct.productId+"' href='#'>"+"<i class='fa fa-plus-square'>"+"</i>Add to wishlist</a></li>"
										+"</ul>"
									+"</div>"
								+"</div>"
						+"</div>");
			}
			});
			
			if(count==0){
				$('#feature_item_content').append("<div style='border:20px solid #fff; border-radius:3px; background-color:#FE980F; color:#fff; padding:10px;'>NO PRODUCT IN THE CART RELATED TO THIS SUBCATEGORY IT WILL BE AVAILABLE SOON.SORRY FOR YOUR ICONVINIENCE</div>");
			}
			
		}
	});
	
	
	
}