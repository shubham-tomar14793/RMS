$(document).ready(function() {
	
	$("#viewCart").click(function(){
		if (localStorage.getItem('cartItems') == null) {
			$('#cartContent').append('<div class="rows">'
			+'<span class="price">No Products</span></div>');
		} else {
			getProductDetails();
		}
	});
	
});
	//getProductDetails();
	
	function getProductDetails(){
		if (localStorage.getItem('cartItems') != null) {
			console.log(localStorage.getItem('cartItems').split(','));
			localProducts = localStorage.getItem('cartItems').split(',');
			localStorageProducts = "[";
			localStorageProductsCount = 0;
			$.each(localProducts,function(index,localProduct){
				$.each(retailerProductsJSON,function(index,retailerProduct){
					if(retailerProduct.productId == localProduct){
						if(localStorageProductsCount !=0)
							localStorageProducts+= ",";
						localStorageProducts+=JSON.stringify(retailerProduct);
						localStorageProductsCount++;
					}
				});
			});
			localStorageProducts+= "]";
			console.log(localStorageProducts);
			productsDisplay(localStorageProducts);
			
		} 
	}
	
	function productsDisplay(data) {
		products = JSON.parse(data);
		var str='';
		var totalprice=0,totalquant=0;
		$('#cartContent').empty();
		$.each(products, function(i,item) {

			str += '<div class="rows">'
			+'<span class="img">'
			+'<img class="img" src=images/products/'+products[i].imagePath+'></img></span>'
			+'<span class="name">'+products[i].productName+'</span>'
			+'<span class="quantity">'+products[i].quantity+'</span>'
			+'<span class="price">'+products[i].price+'</span></div>';
			
			totalprice=totalprice+products[i].price;
			totalquant=totalquant+products[i].quantity;

		});
		$('#cartContent').append(str);
		$('#cartTotal').empty();
		$('#cartTotal').append("<div class=' footercheckout modal-footer'>"+
					"<h3 class='total'>Total</h3>"+
					"<h3 class='totalquantity'>dd</h3>"+

					"<h3 id='totalPrice'>000</h3>"+
					"<a href='login.html' id='checkout'"+
						"class='checkout btn btn-default' >CheckOut</a>"+
				"</div>");
		$('.totalquantity').text(totalquant);

		$('#totalPrice').text(totalprice);

	}



