package com.itc.rms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.services.SearchProductServices;

/**
 * 
 * @author Mohit Garg
 * Emp id-20586
 *
 */
public class SearchProductController {
	
	@Autowired
	SearchProductServices searchProductServices;
	
	/**
	 * method to get all the products by productName
	 * @param productName
	 * @return 
	 */
	@RequestMapping(value = "getProductByName", method = RequestMethod.GET)
	public @ResponseBody String getProductByName(@RequestBody String productName ){		
		return new Gson().toJson(searchProductServices.getProductByName(productName));
	}
	
	/**
	 * method to get all the products by category
	 * @param category
	 * @return
	 */
	@RequestMapping(value = "getProductByCategory", method = RequestMethod.GET)
	public @ResponseBody String getProductByCategory(@RequestBody String category ){		
		return new Gson().toJson(searchProductServices.getProductByCategory(category));
	}
	
	/**
	 * method to get all the products by subCategory
	 * @param subCategory
	 * @return
	 */
	@RequestMapping(value = "getProductBySubCategory", method = RequestMethod.GET)
	public @ResponseBody String getProductBySubCategory(@RequestBody String subCategory ){		
		return new Gson().toJson(searchProductServices.getProductBySubCategory(subCategory));
	}
	
}
