package com.itc.rms.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.Address;
import com.itc.rms.entities.City;
import com.itc.rms.entities.Customer;
import com.itc.rms.entities.User;
import com.itc.rms.serviceimpl.CustomerServiceImpl;
import com.itc.rms.services.CityServices;
import com.itc.rms.services.CustomerServices;



/**
 * 
 * @author Saikat Dey Sarkar
 * @author Swati S
 *
 */
@Controller
public class CustomerController 

{
	@Autowired
	CustomerServices service;
	
	@Autowired
	CityServices cityService;
	
	//Testing
	public CustomerController() {
		service = new CustomerServiceImpl();
	}
	
	@ModelAttribute("getAllCitiesNames")
	public List<String> getAllCitiesNames(){
		List<String> cities = new ArrayList<String>();
		List<City> citiesObj = cityService.getAllCity();
		for (City city : citiesObj) {
			cities.add(city.getCityName());
		}
		return cities;
	}
	
	@RequestMapping(value="register",method=RequestMethod.GET)
	public String getRegisterPage(Model model){
		String viewName="";
		Customer customer = new Customer();
		List<Address> addresses = new ArrayList<>();
		Address address = new Address();
		City city = new City();
		address.setCity(city);
		addresses.add(address);
		customer.setAddresses(addresses);
		
		model.addAttribute("customerObj", customer);
		viewName = "customer/register";
		return viewName;
	}
	
	@RequestMapping(value="register",method=RequestMethod.POST)
	public String addBook(@ModelAttribute("myBookObj")Customer customer,BindingResult errors,Model model){
		String viewName="";
		/*bookValidator.validate(book, errors);
		if(errors.hasErrors()){
			viewName = "addBook";
		}else*/{
			if(service.setCustomerDetails(customer)){
				viewName="login";
			}
		}
		return viewName;
	}
		
	/*
	@RequestMapping(value = "getCustomer", method = RequestMethod.GET)
	public @ResponseBody String getCustomer( long customerId)
	{
		//System.out.println(service.getCustomer(customerId)+"jdj");
		return new Gson().toJson(service.getCustomer(customerId));

	}*/
	@RequestMapping(value = "setCustomer", method = RequestMethod.GET)
	public @ResponseBody boolean setCustomerDetails(Customer customer){
		
		
		if(service.setCustomerDetails(customer))
			return true;
		return false;
		
		//return new Gson().toJson(service.setCustomerDetails(user));
	}
	
	/*@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST)
	public boolean setCustomer(@ModelAttribute("customerObj") User user){
		String viewName = "";
		viewName="registerCustomer";
		Model model = null;
		model.addAttribute("registerCustomer", user);
		return true;
		//return new Gson().toJson(service.setCustomerDetails(customer));
	
	}*/
	
	

}
