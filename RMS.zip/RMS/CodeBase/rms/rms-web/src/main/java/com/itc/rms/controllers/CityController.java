package com.itc.rms.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.City;
import com.itc.rms.services.CityServices;



@Controller
public class CityController {
	

	@Autowired
	CityServices service;
	
	
	@RequestMapping(value = "getAllCity", method = RequestMethod.GET)
	public @ResponseBody String getAllCity() {
		 return new Gson().toJson(service.getAllCity());
	}
	
	@ModelAttribute("getAllCitiesNames")
	public List<String> getAllCitiesNames(){
		List<String> cities = new ArrayList<String>();
		/*List<City> citiesObj = service.getAllCity();
		for (City city : citiesObj) {
			cities.add(city.getCityName());
			System.out.println(city.getCityName());
		}*/
		cities.add("Bangalore");
		return cities;
	}

	

}
