/**
 * @author DEBANJAN SEN (20573)
 * @author PRASOON MEHTA (20588)
 */

package com.itc.rms.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.Category;
import com.itc.rms.entities.Retailer;
import com.itc.rms.serviceimpl.CategoryServiceimpl;
import com.itc.rms.serviceimpl.RetailerServiceImpl;
import com.itc.rms.services.CategoryServices;
import com.itc.rms.services.RetailerServices;


@Controller
public class RetailerController {
	
	@Autowired
	RetailerServices service;
	
	@RequestMapping(value = "addRetailer", method = RequestMethod.GET)
	public @ResponseBody boolean addRetailer(Retailer retailer) {
		 return service.addRetailer(retailer);
	}
	
	@RequestMapping(value = "removeRetailer", method = RequestMethod.GET)
	public @ResponseBody boolean removeRetailer(Retailer retailer) {
		 return service.removeRetailer(retailer);
	}
	
	@RequestMapping(value = "editRetailer", method = RequestMethod.GET)
	public @ResponseBody boolean editRetailer(Retailer retailer) {
		 return service.editRetailer(retailer);
	}
	
	@RequestMapping(value = "viewAllRetailer", method = RequestMethod.GET)
	public @ResponseBody List<Retailer> viewAllRetailer() {
		return service.viewAllRetailer();
	}
	
}
