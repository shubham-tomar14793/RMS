package com.itc.rms.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.Order;
import com.itc.rms.entities.Payment;
import com.itc.rms.entities.SubCategory;
import com.itc.rms.serviceimpl.PaymentServicesImpl;
import com.itc.rms.services.PaymentServices;

@Controller
public class PaymentController {
	
	
	
	public PaymentController() {
		super();
	}
	
	@Autowired
	PaymentServices service;
	
	@RequestMapping(value = "getPaymentDetails", method = RequestMethod.GET)
	
	public @ResponseBody String getPaymentDetails(){
		
				
		
		return new Gson().toJson(service.getPaymentDetails());
	}
	@RequestMapping(value="addPaymentDetails", method = RequestMethod.GET)
	public @ResponseBody boolean addPaymentDetails(Payment payment){
		
		return service.addPaymentDetails(payment);
	}
	
	

}
