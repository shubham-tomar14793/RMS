package com.itc.rms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.Graph;
import com.itc.rms.serviceimpl.GenerateGraphServiceImpl;
import com.itc.rms.services.GenerateGraphServices;

/**
 * 
 * @author Akash Garg 20628
 *
 */
@Controller
public class GenerateGraphController {

	@Autowired
	GenerateGraphServices generateGraph;
	
	
	/*//To test Method
	public GenerateGraphController() {
		// TODO Auto-generated constructor stub
		generateGraph=new GenerateGraphServiceImpl();
		
	}*/
	
	
	@RequestMapping(value = "getAllValueForGraph", method = RequestMethod.GET)
	public @ResponseBody String getAllValueForGraph(){
		return new Gson().toJson(generateGraph.getAllValueForGraph());
	}
}
