package com.itc.rms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.OrderItem;
import com.itc.rms.services.OrderItemService;
@Controller
public class OrderItemController {
	
	@Autowired
	OrderItemService orderItemService;
	
	@RequestMapping(value = "getOrderItem", method = RequestMethod.GET)
	public @ResponseBody String getAllOrders(){
		return new Gson().toJson(orderItemService.getOrderItem());
	}
	
	@RequestMapping(value="addOrderItem",method=RequestMethod.GET)
	public @ResponseBody String addOrderItem(){
		OrderItem orderItem=new OrderItem();
		return new Gson().toJson(orderItemService.addOrderItem(orderItem));
	}
	

	@RequestMapping(value="removeOrderItem",method=RequestMethod.GET)
	public @ResponseBody String removeOrderItem(){
		OrderItem orderItem=new OrderItem();
		return new Gson().toJson(orderItemService.removeOrderItem(orderItem));
	}
	

}
