package com.itc.rms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.services.CompanyServices;

@Controller
public class CompanyController {
	
	@Autowired
	CompanyServices companyServices;
	
	@RequestMapping(value="getAllCompany" ,method=RequestMethod.GET)
	public @ResponseBody String getAllCompany(){
		return new Gson().toJson( companyServices.getAllCompany());
		
	}

}
