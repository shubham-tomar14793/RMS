package com.itc.rms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.Category;
import com.itc.rms.entities.SubCategory;
import com.itc.rms.services.SubCategoryServices;

/**
 * 
 * @author Karan(20564)
 *
 */
@Controller
public class SubCategoryController {

	@Autowired
	SubCategoryServices service;
	
	@RequestMapping(value="createSubCategory", method = RequestMethod.GET)
	public @ResponseBody boolean createSubCategory(){
		SubCategory subCategory= null;
		return service.createSubCategory(subCategory);
	}
	
	@RequestMapping(value="updateSubCategory", method = RequestMethod.GET)
	public @ResponseBody boolean updateSubCategory(){
		SubCategory subCategory=null;
		return service.updateSubCategory(subCategory);
 		
	}
	
	@RequestMapping(value="removeSubCategory", method = RequestMethod.GET)
	public @ResponseBody boolean removeSubCategory(){
		SubCategory subCategory=null;
		return service.removeSubCategory(subCategory);
		
	}
	
	@RequestMapping(value="getAllSubCategories", method = RequestMethod.GET)
	public @ResponseBody String getAllSubCategories(){
		
		return new Gson().toJson(service.getAllSubCategories());
	}
	
	@RequestMapping(value="getSubCategoriesByCategory", method = RequestMethod.GET)
	public @ResponseBody String getSubCategoriesByCategory(){
		Category category=null;
		return new Gson().toJson(service.getSubCategoriesByCategory(category));
	}
	
}

