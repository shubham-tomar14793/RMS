package com.itc.rms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.dao.OrderAddressDAO;
import com.itc.rms.entities.OrderAddress;
import com.itc.rms.services.OrderAddressService;
@Controller
public class OrderAddressController {
	
	@Autowired
	OrderAddressService orderAddressService;
	
	@RequestMapping(value = "addOrderAddress", method = RequestMethod.GET)
	public @ResponseBody String addOrderAddress()
	{
		OrderAddress orderAddress=new OrderAddress();
		orderAddress.setAddress("Bangalore");
		return new Gson().toJson(orderAddressService.addOrderAddress(orderAddress));
	}
	
	@RequestMapping(value = "getOrderAddress", method = RequestMethod.GET)
	public @ResponseBody String getOrderAddress(Long orderAddressId)
	{
		//OrderAddress orderAddress=new OrderAddress();
		return new Gson().toJson(orderAddressService.getOrderAddress(orderAddressId));
	}
	
	@RequestMapping(value = "getOrderAddressList", method = RequestMethod.GET)
	public @ResponseBody String getOrderAddress()
	{
		
		return new Gson().toJson(orderAddressService.getOrderAddress());
	}
	

}
