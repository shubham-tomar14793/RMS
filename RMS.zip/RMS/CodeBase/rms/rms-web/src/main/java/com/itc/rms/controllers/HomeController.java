package com.itc.rms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itc.rms.entities.Category;
import com.itc.rms.entities.RetailerProduct;
import com.itc.rms.serviceimpl.HomeServicesImpl;
import com.itc.rms.services.HomeServices;

/**
 * 
 * @author shubham
 *
 */

@Controller
public class HomeController {

	@Autowired
	HomeServices service;
			
	/**
	 * View Products
	 * @return
	 */
	@RequestMapping(value = "viewAllRetailerProduct", method = RequestMethod.GET)
    public @ResponseBody List<RetailerProduct> viewAllRetailerProduct(){
    	System.out.println("homeController");
		return service.getAllRetailerProduct();
	}	
}
