package com.itc.rms.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AuthenticationController {

	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String getHome(){
		return "customer/home";
	}
	
	@RequestMapping(value = "home", method = RequestMethod.GET)
	public String getHomePage(){
		return "customer/home";
	}
	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String getLoginPAge(){
		return "login";
	}
	
	@RequestMapping(value="loginError",method=RequestMethod.GET)
	public String showLoginError(Model model){
		model.addAttribute("login_error", 1);
		return "login";
	}
	
	@RequestMapping(value="getLoginUser",method=RequestMethod.GET)
	public @ResponseBody String getLoginUser(){
		return RoleBasedAuthenticationHandler.getSessionEmailId();
	}
}
