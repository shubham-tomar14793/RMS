package com.itc.rms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.itc.rms.entities.Customer;
import com.itc.rms.entities.Order;
import com.itc.rms.entities.User;
import com.itc.rms.services.CustomerServices;
import com.itc.rms.services.OrderService;

@Controller
public class OrderController {
	
	@Autowired
	OrderService orderServices;
	
	@Autowired
	CustomerServices customerService;
	
	
	@RequestMapping(value = "placeOrder", method = RequestMethod.GET)
	public ModelAndView getPlaceOrderPage(Model model){
		
		User user = customerService.getCustomerByEmailId(RoleBasedAuthenticationHandler.getSessionEmailId());
		
		return new ModelAndView("reg-customer/placeOrder","customerObj",user);
	}
	
	@RequestMapping(value = "getAllOrders", method = RequestMethod.GET)
	public @ResponseBody String getAllOrders() {
		
		return new Gson().toJson(orderServices.getAllOrders());
	}
	
	@RequestMapping(value = "getOrderById", method = RequestMethod.GET)
	public @ResponseBody String getOrderById(@RequestParam("order") Order order) {
		
		
		return new Gson().toJson(orderServices.getOrderById(order.getOrderId()));
	}
	
	@RequestMapping(value = "getAllOrdersByUserId", method = RequestMethod.GET)
	public @ResponseBody String getAllOrdersByUserId(@RequestParam("user") User user) {
		
		return new Gson().toJson(orderServices.getAllOrdersByUserId(user.getUserId()));
	}

}
