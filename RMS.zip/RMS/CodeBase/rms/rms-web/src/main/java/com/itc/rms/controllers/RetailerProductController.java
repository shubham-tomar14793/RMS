package com.itc.rms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.services.RetailerProductServices;

@Controller
public class RetailerProductController {
	
	@Autowired
	RetailerProductServices service;
	
	@RequestMapping(value = "getAllRetailerProducts", method = RequestMethod.GET)
	public @ResponseBody String getAllProducts(){
		/*for (RetailerProduct product : service.getAllProducts()) {
			System.out.println(product.toString());
			//System.out.println(product.toString());
		}*/
		return new Gson().toJson(service.getAllProducts());
	}
}
