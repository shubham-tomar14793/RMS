package com.itc.rms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itc.rms.entities.Category;
import com.itc.rms.serviceimpl.CategoryServiceimpl;
import com.itc.rms.serviceimpl.WishListServicesImpl;
import com.itc.rms.services.CategoryServices;
import com.itc.rms.services.WishListServices;

@Controller
public class WishListController {
	
	@Autowired
	WishListServices service;
	
	/*//To test methods
	public WishListController(){
		service = new WishListServicesImpl();
	}
	
	@RequestMapping(value = "viewCategoryPage", method = RequestMethod.GET)
	public String getCategoryPage(Category cat){
		//Category cat = null;
		return "admin/viewCategories";
	}
	*/
	
	/**
	 * add Category
	 * @return
	 */
//	@RequestMapping(value = "addCategory", method = RequestMethod.GET)
//	public @ResponseBody boolean addCategory(@RequestBody String name){
//		Category category = new Category();
//		category.setCategoryName(name);
//		return service.addCategory(category);
//	}
//	/**
//	 * remove Category
//	 * @return
//	 */
//	
//	@RequestMapping(value = "removeCat", method = RequestMethod.GET)
//	public @ResponseBody boolean removeCategory(Category cat){
//		
//		//Category cat = null;
//		return service.removeCategory(cat);
//	}
//	
//	/**
//	 * edit Category
//	 * @return
//	 */


}
