package com.itc.rms.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.itc.rms.entities.Category;
import com.itc.rms.serviceimpl.CategoryServiceimpl;
import com.itc.rms.services.CategoryServices;

/**
 * 
 * @author Abhishek Singh
 *
 */
@Controller
public class CategoryController {

	@Autowired
	CategoryServices service;
	
	/*//To test methods
	public CategoryController(){
		service = new CategoryServiceimpl();
	}*/
	
	@RequestMapping(value = "viewCategoryPage", method = RequestMethod.GET)
	public String getCategoryPage(Category cat){
		//Category cat = null;
		return "admin/viewCategories";
	}
	
	/**
	 * Method to get all categories
	 * @return
	 */
	@RequestMapping(value = "getAllCategories", method = RequestMethod.GET)
	public @ResponseBody String getAllCategories(){
		return new Gson().toJson(service.viewCategory());
	}
	
	/**
	 * add Category
	 * @return
	 */
	@RequestMapping(value = "addCategory", method = RequestMethod.GET)
	public @ResponseBody boolean addCategory(){
		Category category = new Category();
		return service.addCategory(category);
	}
	/**
	 * remove Category
	 * @return
	 */
	
	@RequestMapping(value = "removeCat", method = RequestMethod.GET)
	public @ResponseBody boolean removeCategory(Category cat){
		
		//Category cat = null;
		return service.removeCategory(cat);
	}
	
	/**
	 * edit Category
	 * @return
	 */
	@RequestMapping(value = "editCat", method = RequestMethod.GET)
	public @ResponseBody boolean editCategory(){
		
		Category cat = null;
		return service.editCategory(cat);
	}
	
	/**
	 * view Category
	 */
	@RequestMapping(value = "viewCat", method = RequestMethod.GET)
	public @ResponseBody List<Category> viewCategory(){
		
		/*return new Gson().toJson(service.viewCategory());*/
		return service.viewCategory();
	}
	
}
