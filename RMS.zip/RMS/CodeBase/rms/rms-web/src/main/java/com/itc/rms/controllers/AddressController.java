package com.itc.rms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.itc.rms.entities.Address;
import com.itc.rms.entities.User;
import com.itc.rms.serviceimpl.AddressServiceImpl;
import com.itc.rms.services.AddressServices;

@Controller
public class AddressController {

	@Autowired
	AddressServices addressServices;
	
	public AddressController() {
		addressServices = new AddressServiceImpl();
	}
	/*@RequestMapping(value = "getAllAddress", method = RequestMethod.GET)
	public @ResponseBody String getAllAddress(long userId){
		for (Address address : addressServices.getAllAddress(userId)) {
			System.out.println(address.toString());
			
		}
		return new Gson().toJson(addressServices.getAllAddress(userId));
	}*/
	
	public List<Address> getAllAddress(long userId){
		for (Address address : addressServices.getAllAddress(userId)) {
			System.out.println(address.toString());
			
		}
		return addressServices.getAllAddress(userId);
	}
	@RequestMapping(value = "addAddress", method = RequestMethod.GET)
	public @ResponseBody boolean address(Address address,long userId){
		
		
		if(addressServices.addAddress(address, userId))
			return true;
		return false;
	}
	
}
