package com.itc.rms.utilities;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaUtil {

	private static EntityManagerFactory entityManagerFactory;
	private JpaUtil(){
		
	}
	public static EntityManagerFactory getEntityFactory(){
		return (entityManagerFactory == null)
				?entityManagerFactory = Persistence.createEntityManagerFactory("rms")
				:entityManagerFactory;
	}
}
