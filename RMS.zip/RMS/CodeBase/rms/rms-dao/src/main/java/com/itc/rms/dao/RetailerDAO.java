package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Offer;
import com.itc.rms.entities.Retailer;
/**
 * 
 * @author Prasoon Mehta
 *
 */
public interface RetailerDAO {
	
	/**
	 * Method to add Retailer
	 * @param retailer
	 * @return
	 */
	abstract boolean addRetailer(Retailer retailer);
	/**
	 * Method to update Retailer
	 * @param retailer
	 * @return
	 */
	abstract boolean editRetailer(Retailer retailer);
	/**
	 * Method to delete Retailer
	 * @param retailer
	 * @return
	 */
	abstract boolean removeRetailer(Retailer retailer);
	
	/**
	 * Method to get all Retailer
	 * @return list of retailers
	 */
	abstract List<Retailer> getAllRetailer();

}
