package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Order;
import com.itc.rms.entities.Payment;

/**
 * 
 * @author Debolina
 *
 */


public interface PaymentDAO {
	/**
	 * Method to add payment details
	 * @param payment
	 * @return boolean
	 */
	
	public abstract boolean addPaymentDetails(Payment payment);
	
	/**
	 * Method to get list of payment details
	 * @return List<Payment>
	 */
	public abstract List<Payment> getPaymentDeatils();
	
	/**
	 * Method to get a particular payment detail by order
	 * @param order
	 * @return
	 */
	
	public abstract Payment getPaymentDetailsByOrder(Order order);

}
