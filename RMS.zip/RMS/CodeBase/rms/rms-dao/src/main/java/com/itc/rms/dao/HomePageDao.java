package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.RetailerProduct;

/**
 * 
 * @author shubham
 *
 */
public interface HomePageDao{
   List<RetailerProduct> getAllRetailerProduct();
}
