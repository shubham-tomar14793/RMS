package com.itc.rms.dao;

import java.util.List;
import com.itc.rms.entities.RetailerProduct;

/**
 * 
 * @author shubham
 *
 */
public interface RetailerProductDAO {

	/**
	 * Method to get all the Retailer Product available.
	 * @return List of Retailer Product
	 */
	public abstract List<RetailerProduct> getAllRetailerProducts();
	/**
	 * 
	 * @param retailerProduct
	 * @return
	 */
	public boolean addRetailerProduct(RetailerProduct retailerProduct);
	/**
	 * 
	 * @param retailerProduct
	 * @return
	 */
	public boolean deleteRetailerProduct(RetailerProduct retailerProduct);
	/**
	 * 
	 * @param retailerProduct
	 * @return
	 */
	public boolean updateRetailerProduct(RetailerProduct retailerProduct);
}
