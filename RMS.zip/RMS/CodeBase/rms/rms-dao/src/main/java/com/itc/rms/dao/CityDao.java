package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.City;

public interface CityDao {
	boolean addCity(City city);
	List<City> getAllCity();

}
