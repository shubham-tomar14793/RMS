package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Category;
/**
 * 
 * @author Abhishek Singh(20596)
 *
 */

public interface CategoryDAO {
	
	/**
	 * Method to get add category
	 * @param category
	 * @return
	 */
	public abstract boolean addCategory(Category category);
	/**
	 * Method to get remove category
	 * @param category
	 * @return
	 */
	public abstract boolean removeCategory(Category category);
	/**
	 * Method to get edit category
	 * @param category
	 * @return
	 */
	public abstract boolean editCategory(Category category);
	/**
	 * Method to view category
	 * @return
	 */
	public abstract List<Category> viewCategory();
	
}
