package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Retailer;

/**
 * 
 * @author shubham
 *
 */


public interface AdminDao {
	
	/**
	 * 
	 * @return Boolean 
	 * Checks Whether the Retailer has been added successfully(true if added, false if not)
	 */
    public boolean addRetailer();
    /**
     * 
     * @param retailer
     * @return Boolean
     * check whether Retailer deleted successfully(true if deleted,false if not)
     */    
    public boolean removeRetailer(Retailer retailer);
    /**
     * 
     * @param retailer
     * @return Boolean
     * checks whether Retailer credentials updated successfully(true if added,false if not)
     */
    public boolean updateRetailer(Retailer retailer);
    
    /**
     * 
     * @param retailer
     * @return List of all the Retailers available in the area
     */
    public List<Retailer> getAllRetailer(Retailer retailer);
       
}
