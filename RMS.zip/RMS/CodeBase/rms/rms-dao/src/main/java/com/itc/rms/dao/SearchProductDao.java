package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Category;
import com.itc.rms.entities.Product;
import com.itc.rms.entities.SubCategory;

/**
 * 
 * @author Mohit Garg
 *Emp-Id = 20586
 */
public interface SearchProductDao {

	/**
	 * @param productName
	 * @return list of Products
	 * this method is to get the list of products by name 
	 */
	public abstract List<Product> getProductByName(String productName);
	/**
	 * 
	 * @param category
	 * @return
	 * this method is to get the list of product by category 
	 */
	public abstract List<Product> getProductByCategory(String category);
	/**
	 * 
	 * @param subCategory
	 * @return list of products
	 * this method will get the list of products by subCategory
	 */
	public abstract List<Product> getProductBySubCategory(String subCategory);
}
