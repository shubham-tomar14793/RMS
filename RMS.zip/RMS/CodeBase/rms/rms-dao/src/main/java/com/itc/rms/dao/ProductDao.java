package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Product;
/**
 * @author Devesh Rajput
 */
public interface ProductDao {

	/**
	 * Method to get All Products
	 * @return List Of products
	 */
	abstract List<Product> getAllProducts();
	/**
	 * Method to add Product
	 * @param product
	 * @return
	 */
	abstract boolean addProduct(Product product);
	/**
	 * Method to update an Product
	 * @param product
	 * @return
	 */
	abstract boolean updateProduct(Product product);
	/**
	 * Method to delete an Product
	 * @param product
	 * @return
	 */
	abstract boolean deleteProduct(Product product);
	
}
