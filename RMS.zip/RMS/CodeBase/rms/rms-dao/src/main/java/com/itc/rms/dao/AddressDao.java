/**
 * 
 * @author Ranjitha
 *
 */
package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Address;

/**
 * 
 * Inteface of Address DAO 
 *
 */
public interface AddressDao {

	/**
	 * Method to display all Address
	 * @return
	 */
	public  List<Address> getAllAddress(long userId);
	/**
	 * Method to add Address
	 * @return
	 */
	public boolean addAddress(Address address,long userId);
	/**
	 * Method to edit Address
	 * @return
	 */
	public boolean editAddress(Address address);
	/**
	 * Method to delete Address
	 * @return
	 */
	public boolean deleteAddress(Address address);
}
