package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.User;


/**
 * 
 * @author swati
 *
 */
public interface UserDAO {
	/**
	 * 
	 * @param User
	 * @return
	 */
	public abstract void setUserDetails();
}
