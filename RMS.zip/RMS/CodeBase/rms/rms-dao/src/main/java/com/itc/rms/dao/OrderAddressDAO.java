package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.OrderAddress;

/**
 * @author Anushka
 */
public interface OrderAddressDAO {

	/**
	 * 
	 * 
	 * @param orderAddress
	 * @return order address of the customer
	 */
  public abstract boolean  addOrderAddress(OrderAddress orderAddress);
  /**
   * 
   * @param order_Address_Id
   * @return get the order address
   */
  public abstract OrderAddress getOrderAddress(Long order_Address_Id);
  /**
   * 
   * @return list of order addresses
   */
  public abstract List<OrderAddress> getOrderAddress();
	
}
