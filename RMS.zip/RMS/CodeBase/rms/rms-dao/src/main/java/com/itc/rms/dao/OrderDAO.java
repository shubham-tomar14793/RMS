package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Order;


/**
 * 
 * @author Akash Jothish
 * @author Arnab Datta
 * @author Anushka,Rohit
 */

public interface OrderDAO {
	
	/**
	 * Method to get all orders for a particular user
	 * @param userId
	 * @return
	 */
	public abstract List<Order> getAllOrders();
	
	public abstract Order getOrderById(long orderId);
	
	public abstract List<Order> getAllOrdersByUserId(long userId);
	/**
	 * 
	 * @param orderId
	 * @return
	 */
	public abstract Order getOrder(Long orderId);
	/**
	 * 
	 * @param order
	 * @return
	 */
	public abstract boolean addOrder(Order order);
	/**
	 * 
	 * @param order
	 * @return
	 */
	public abstract boolean removeOrder(Order order);

}
