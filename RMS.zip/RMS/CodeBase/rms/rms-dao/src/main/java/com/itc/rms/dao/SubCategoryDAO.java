package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Category;
import com.itc.rms.entities.SubCategory;

/**
 * 
 * @author Karan(20564)
 *
 */
public interface SubCategoryDAO {
	
	/**
	 * Method to create a new Sub-Category
	 * @param subCategory
	 * @return
	 */
	public abstract boolean createSubCategory(SubCategory subCategory);
	
	/**
	 * Method to remove a Sub-Category
	 * @param subCategory
	 * @return
	 */
	public abstract boolean removeSubCategory(SubCategory subCategory);
	
	/**
	 * Method to update the Sub-Category
	 * @param subCategory
	 * @return
	 */
	public abstract boolean updateSubCategory(SubCategory subCategory);
	
	/**
	 * Method to retrieve all the Sub-Categories
	 * @return
	 */
	public abstract List<SubCategory> getAllSubCategories();
	
	/**
	 * Method to get Sub-Categories based on Category which it belongs to. 
	 * @param category
	 * @return
	 */
	public abstract List<SubCategory> getSubCategoriesByCategory(Category category);

}
