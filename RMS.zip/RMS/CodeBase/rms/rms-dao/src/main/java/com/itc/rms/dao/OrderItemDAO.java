package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Order;
import com.itc.rms.entities.OrderItem;

/**
 * @author Anushka
 */
public interface OrderItemDAO {
	
	/**
	 *@return list of order items
	 */
 public abstract List<OrderItem> getOrderItem();
 /**
  * @return order item based on order_Id
  */
  public abstract OrderItem getOrderItem(Long order_Id);
  
  /**
   * 
   * @param order
   * @return to add order item
   */
  public abstract boolean addOrderItem(OrderItem orderItem);
  
  public abstract boolean removeOrderItem(OrderItem orderItem);

}
