package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Offer;
/**
 * 
 * @author Devesh Rajput
 * EmpId 20594
 *
 */
public interface OfferDao {
	/**
	 * Method to get all Offers
	 * @return list of offers
	 */
	abstract List<Offer> getAllOffers();
	/**
	 * Method to get all retailer Offers
	 * @param retailerId
	 * @return
	 */
	abstract List<Offer> getAllRetailerOffers(long retailerId);
	/**
	 * Method to add Offer
	 * @param offer
	 * @return
	 */
	abstract boolean addOffer(Offer offer);
	/**
	 * Method to update an offer
	 * @param offer
	 * @return
	 */
	abstract boolean updateOffer(Offer offer);
	/**
	 * Method to delete an offer
	 * @param offer
	 * @return
	 */
	abstract boolean deleteOffer(Offer offer);


}
