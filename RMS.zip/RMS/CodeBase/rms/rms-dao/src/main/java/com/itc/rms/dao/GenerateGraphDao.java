package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Graph;

/**
 * 
 * @author akash Garg 20628
 *
 */
public interface GenerateGraphDao {

	/**
	 * 
	 * @return Get all value from database for plotting Total sales vs months graph
	 */
	public abstract List<Graph> getAllValueForGraph();
}
