package com.itc.rms.dao;

import java.util.List;

import com.itc.rms.entities.Customer;
import com.itc.rms.entities.User;

/**
 * 
 * @author Devesh Rajput, Saikat Dey sarkar
 *
 */

public interface CustomerDao {

	/**
	 * Method to get all Customers
	 * @return list of Customers
	 */
	abstract List<Customer> getAllCustomers();
	
	/**
	 * Method to add Customer
	 * @param Customer
	 * @return
	 */
	abstract boolean addCustomer(Customer customer);
	/**
	 * Method to update a Customer
	 * @param Customer
	 * @return
	 */
	abstract boolean updateCustomer(Customer customer);
	/**
	 * Method to delete a Customer
	 * @param Customer
	 * @return
	 */
	abstract boolean deleteCustomer(Customer customer);
	
	abstract Customer getCustomer(long customerId);

	abstract User getCustomerByEmailId(String emailId);
	
}
