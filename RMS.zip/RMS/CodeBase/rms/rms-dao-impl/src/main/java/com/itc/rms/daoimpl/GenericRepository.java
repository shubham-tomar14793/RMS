package com.itc.rms.daoimpl;



import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.itc.rms.utilities.JpaUtil;

@Repository
public class GenericRepository<T, L> {

	private EntityManagerFactory entityManagerFactory = null;

	public GenericRepository() {
		this.entityManagerFactory = JpaUtil.getEntityFactory();
	}

	public boolean create(T object) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction tx = null;
			boolean ans=false;
		try {
			tx = entityManager.getTransaction();
			tx.begin();
			entityManager.persist(object);
			tx.commit();
			entityManager.close();
			ans=true;
		} catch (RuntimeException e) {
			System.out.println("error while inserting "+e.getMessage());
			e.printStackTrace();
			
		}
		return ans;
	}

	public List<T> getAll(Class clazz) {
		javax.persistence.Entity entityAnn = (Entity) clazz.getAnnotation(javax.persistence.Entity.class);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("select t from "+entityAnn.name()+" t");
		return query.getResultList();
	}

	public boolean update(T object) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction tx = null;
		try {
			tx = entityManager.getTransaction();
			tx.begin();
			entityManager.merge(object);
		} catch (RuntimeException e) {
			tx.rollback();
			return false;
		}
		finally{
			tx.commit();
		}
		return true;
	}

	public boolean remove(T object) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction tx = null;
		try {
			tx = entityManager.getTransaction();
			tx.begin();
			Object object1 = entityManager.merge(object);
			entityManager.remove(object1);
			entityManager.close();
		} catch (RuntimeException e) {
			tx.rollback();
			return false;
		}
		finally{
			tx.commit();
		}
		return true;
	}

	public T get(Class clazz,L id) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return (T) entityManager.find(clazz, id);
	}
	
	public List<T> queryBuilder(Class clazz , List<String> qry)
	{
		javax.persistence.Entity entityAnn = (Entity) clazz.getAnnotation(javax.persistence.Entity.class);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("select t from "+entityAnn.name()+" t" + qry.get(0));
		
		for(int i=1;i<qry.size();i++)
			query.setParameter(i,qry.get(i));
				
		try
		{
			return query.getResultList();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public boolean deleteQueryBuilder(Class clazz , List<String> qry)
	{
		javax.persistence.Entity entityAnn = (Entity) clazz.getAnnotation(javax.persistence.Entity.class);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("delete t from "+entityAnn.name()+" t" + qry.get(0));
		
		for(int i=1;i<qry.size();i++)
			query.setParameter(i,qry.get(i));
				
		try
		{
			query.getResultList();
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
}
