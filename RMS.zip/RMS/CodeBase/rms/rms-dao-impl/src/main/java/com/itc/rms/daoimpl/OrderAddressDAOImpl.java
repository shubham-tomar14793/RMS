package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.OrderAddressDAO;
import com.itc.rms.entities.Order;
import com.itc.rms.entities.OrderAddress;

@Repository
public class OrderAddressDAOImpl implements OrderAddressDAO {

	@Autowired
	GenericRepository<OrderAddress,Long> orderAddressDao;
	
	@Override
	public boolean  addOrderAddress(OrderAddress orderAddress) {
		if(!orderAddressDao.create(orderAddress))
			return false;
		
		return true;
		
	}

	@Override
	public OrderAddress getOrderAddress(Long order_Address_Id) {
		return orderAddressDao.get(Order.class, order_Address_Id);
	
	}

	@Override
	public List<OrderAddress> getOrderAddress() {
	 return orderAddressDao.getAll(OrderAddress.class);
	}
}
