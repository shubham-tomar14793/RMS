package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.CategoryDAO;
import com.itc.rms.entities.Category;

/**
 * 
 * @author Abhishek Singh
 *
 */


@Repository("CategoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	@Autowired
	GenericRepository<Category,Long> cat;
	
	public CategoryDAOImpl(){
		cat = new GenericRepository<Category,Long>();
	}
	/**
	 * method to add category
	 */
	
	@Override
	public boolean addCategory(Category category){
		return cat.create(category);
	}

	/**
	 * method to remove category
	 */
	@Override
	public boolean removeCategory(Category category) {
		boolean ans=false;
		if(cat.remove(category)==true)
		ans=true;
		
		return ans;
	}

	/**
	 * method to edit category
	 */
	@Override
	public boolean editCategory(Category category) {
		boolean ans=false;
		if(cat.update(category)==true)
		ans= true;		
		return ans;
	}

	/**
	 * method to view category
	 */
	@Override
	public List<Category> viewCategory() {
		return cat.getAll(Category.class);
		
	}

}
