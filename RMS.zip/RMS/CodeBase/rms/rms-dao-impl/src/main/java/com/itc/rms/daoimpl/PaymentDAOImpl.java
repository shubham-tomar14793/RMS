package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.PaymentDAO;
import com.itc.rms.entities.Order;
import com.itc.rms.entities.Payment;

/**
 * 
 * @author Debolina
 *
 */

@Repository("PaymentDAO")
public class PaymentDAOImpl implements PaymentDAO {

	
	
	
	
	
	public PaymentDAOImpl() {
		super();
		
	}


	@Autowired
	GenericRepository<Payment,Long> repository;
	
	
	@Override
	public boolean addPaymentDetails(Payment payment) {
		return(repository.create(payment));
		 
	}


	@Override
	public List<Payment> getPaymentDeatils() {
		return repository.getAll(Payment.class);
	}


	@Override
	public Payment getPaymentDetailsByOrder(Order order) {
		return repository.get(Order.class, order.getOrderId());
	}

}
