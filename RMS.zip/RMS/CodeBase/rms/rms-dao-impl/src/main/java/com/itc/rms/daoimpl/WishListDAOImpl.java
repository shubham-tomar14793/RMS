package com.itc.rms.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.WishListDAO;
import com.itc.rms.entities.RetailerProduct;
import com.itc.rms.utilities.JpaUtil;


@Repository("WishListDAO")
public class WishListDAOImpl implements WishListDAO {

	@Autowired
	GenericRepository<RetailerProduct,Long> repo;
	
	private EntityManagerFactory entityManagerFactory = null;
	
	@Override
	public List<RetailerProduct> getWishListByUserId(long userId) {
		entityManagerFactory = JpaUtil.getEntityFactory();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("");
		/*select * from retailerproduct where productID IN(select retailerProduct_productID from retailerproduct_wishlist where wishLists_wish_list_id=(select wish_list_id from customer where userID="+userId+"))*/
		return (List<RetailerProduct>)query.getResultList();
	}
	
	@Override
	public boolean addRetailerProduct(RetailerProduct retailerProduct,long userId) {
		
		entityManagerFactory = JpaUtil.getEntityFactory();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction tx = null;
		try {
			tx = entityManager.getTransaction();
			tx.begin();
//			entityManager.merge();
		} catch (RuntimeException e) {
			tx.rollback();
			return false;
		}
		finally{
			tx.commit();
		}
		return true;
	}

	@Override
	public boolean removeRetailerProduct(RetailerProduct retailerProduct,long userId) {
		entityManagerFactory = JpaUtil.getEntityFactory();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction tx = null;
		Query query = entityManager.createQuery("");
		/*delete from retailerproduct_wishlist where  (wishLists_wish_list_id=(select wish_list_id from customer where userID="+userId+") and retailerProduct_productID="+retailerProduct.getProductId()+")*/

		try {
			tx = entityManager.getTransaction();
			tx.begin();
//			entityManager.merge();
		} catch (RuntimeException e) {
			tx.rollback();
			return false;
		}
		finally{
			tx.commit();
		}
		return true;
	}

}
