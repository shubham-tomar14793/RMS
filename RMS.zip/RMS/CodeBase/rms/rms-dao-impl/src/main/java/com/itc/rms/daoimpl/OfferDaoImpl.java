package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.OfferDao;
import com.itc.rms.entities.Offer;

/**
 * 
 * @author Devesh Rajput
 *  EmpId 20594
 *
 */

@Repository("OfferDao")
public class OfferDaoImpl implements OfferDao{

	@Autowired
	GenericRepository<Offer,Long> repo;
	
	/**
	 * Method to get all Offers
	 * @return list of offers
	 */
	@Override
	public List<Offer> getAllOffers() {
		
		return repo.getAll(Offer.class);
	}
	/**
	 * Method to add Offer
	 * @param offer
	 * @return boolean
	 */
	@Override
	public boolean addOffer(Offer offer) {
		return repo.create(offer);
	}
	/**
	 * Method to update an offer
	 * @param offer
	 * @return boolean
	 */

	@Override
	public boolean updateOffer(Offer offer) {
		
		return repo.update(offer);
	}
	/**
	 * Method to delete an offer
	 * @param offer
	 * @return boolean
	 */
	@Override
	public boolean deleteOffer(Offer offer) {
		
		return repo.remove(offer);
	}
	/**
	 * Method to get all retailer Offers
	 * @param retailerId
	 * @return List of offers belonging to a particular table
	 */

	@Override
	public List<Offer> getAllRetailerOffers(long retailerId) {
		
		return (List<Offer>) repo.get(Offer.class, retailerId);
	}

	
	
	

}
