package com.itc.rms.daoimpl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.entities.Offer;
import com.itc.rms.entities.Retailer;
import com.itc.rms.entities.RetailerProduct;
import com.itc.rms.dao.*;

@Repository
public class RetailerDAOImpl implements RetailerDAO{

	
	@Autowired
	GenericRepository<Retailer,Long> repo;

	/**
	 * Add retailer to Database
	 * @see com.itc.rms.dao.RetailerDAO#addRetailer(com.itc.rms.entities.Retailer)
	 */
	
	@Override
	public boolean addRetailer(Retailer retailer) {
		return repo.create(retailer);
	}

	/**
	 * Remove retailer from Database
	 * @see com.itc.rms.dao.RetailerDAO#addRetailer(com.itc.rms.entities.Retailer)
	 */
	
	@Override
	public boolean removeRetailer(Retailer retailer) {
		return repo.remove(retailer);
	}

	/**
	 * Edit retailer in database
	 * @see com.itc.rms.dao.RetailerDAO#addRetailer(com.itc.rms.entities.Retailer)
	 */
	
	@Override
	public boolean editRetailer(Retailer retailer) {
		return repo.update(retailer);
	}

	
	
	/**
	 * @ author Debanjan 20573
	 * View all retailers in the database
	 */
 
	@Override
	public List<Retailer> getAllRetailer() {
		return repo.getAll(Retailer.class);
	}
	
	}

