package com.itc.rms.daoimpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.OrderDAO;
import com.itc.rms.entities.Order;
@Repository
public class OrderDAOImpl implements OrderDAO{
	
	//@Autowired
	GenericRepository<Order,Long> orderDAO=new GenericRepository<>();

	@Override
	public List<Order> getAllOrders() {
		
		return orderDAO.getAll(Order.class);
	}

	public OrderDAOImpl() {
		super();
	}

	@Override
	public Order getOrderById(long orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> getAllOrdersByUserId(long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order getOrder(Long orderId) {
		
		return orderDAO.get(Order.class, orderId);
	}

	@Override
	public boolean addOrder(Order order) {
		if(!orderDAO.create(order))
		return false;
		
		return true;
	}

	@Override
	public boolean removeOrder(Order order) {
		if(!orderDAO.remove(order))
			return false;
		
		return true;
	}
 public boolean  cancelOrder(Order order){
	 return false;
 }
}
