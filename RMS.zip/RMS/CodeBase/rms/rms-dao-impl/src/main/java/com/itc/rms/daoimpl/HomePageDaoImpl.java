package com.itc.rms.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.HomePageDao;
import com.itc.rms.entities.Retailer;
import com.itc.rms.entities.RetailerProduct;
import com.itc.rms.utilities.JpaUtil;

@Repository
public class HomePageDaoImpl implements HomePageDao {
	
	private EntityManagerFactory entityManagerFactory = null;
	@Autowired
	GenericRepository<Retailer,Long> genericRepository;
	
	@Override
	public List<RetailerProduct> getAllRetailerProduct() {
		System.out.println("HomePageDaoImpl");
		entityManagerFactory=JpaUtil.getEntityFactory();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entitymanagercreated");
		Query query = entityManager.createQuery("select rp from RetailerProduct rp");
		System.out.println("query created");
		try
		{
			System.out.println("getting the result");
			return query.getResultList();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}    
	 }  
}
