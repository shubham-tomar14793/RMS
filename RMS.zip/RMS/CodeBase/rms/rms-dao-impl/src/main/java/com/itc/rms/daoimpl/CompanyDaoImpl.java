package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.CompanyDao;
import com.itc.rms.entities.Company;

@Repository
public class CompanyDaoImpl implements CompanyDao{

	@Autowired
	GenericRepository<Company, Long> companyRepo;
	@Override
	public boolean addCompany(Company company) {
		// TODO Auto-generated method stub
		return companyRepo.create(company);
	}

	@Override
	public boolean removeCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean editCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Company> getAllCompany() {
List<Company> companies=	companyRepo.getAll(Company.class);
//System.out.println(company.get(0).getCompanyName()+"000");
return companies;
	}

}
