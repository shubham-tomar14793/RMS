package com.itc.rms.daoimpl;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.SubCategoryDAO;
import com.itc.rms.entities.Category;
import com.itc.rms.entities.SubCategory;

/**
 * 
 * @author Karan(20564)
 *
 */
@Repository("SubCategoryDAO")
public class SubCategoryDAOImpl implements SubCategoryDAO{
	
	private EntityManagerFactory entityManagerFactory = null;

	@Autowired
	GenericRepository<SubCategory,Long> genericRepository;
	
	@Override
	public boolean createSubCategory(SubCategory subCategory) {
		return genericRepository.create(subCategory); 
	}

	@Override
	public boolean removeSubCategory(SubCategory subCategory) {
		return genericRepository.remove(subCategory);
	}

	@Override
	public boolean updateSubCategory(SubCategory subCategory) {
		return genericRepository.update(subCategory);
	}

	@Override
	public List<SubCategory> getAllSubCategories() {
		return genericRepository.getAll(SubCategory.class);
	}

	@Override
	public List<SubCategory> getSubCategoriesByCategory(Category category) {
		Entity entityAnn = SubCategory.class.getAnnotation(Entity.class);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("select t from "+entityAnn.name()+" t where t.category_id="+category.getCategoryId());
		
		return query.getResultList();
	}

}
