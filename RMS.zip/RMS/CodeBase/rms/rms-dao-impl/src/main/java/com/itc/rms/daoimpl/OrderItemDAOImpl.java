package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.OrderItemDAO;
import com.itc.rms.entities.Order;
import com.itc.rms.entities.OrderItem;
@Repository
public class OrderItemDAOImpl implements OrderItemDAO{

	@Autowired
	GenericRepository<OrderItem,Long> orderItemDao;
	
	@Override
	public List<OrderItem> getOrderItem() {	
		return orderItemDao.getAll(OrderItem.class);
	}

	@Override
	public OrderItem getOrderItem(Long order_Id) {
		return orderItemDao.get(Order.class, order_Id);
	}


	@Override
	public boolean addOrderItem(OrderItem orderItem) {
		if(!orderItemDao.create(orderItem))
			return false;
		
		return true;
	}

	@Override
	public boolean removeOrderItem(OrderItem orderItem) {
		if(!orderItemDao.remove(orderItem))
		return false;
		
		return true;
	}
}
