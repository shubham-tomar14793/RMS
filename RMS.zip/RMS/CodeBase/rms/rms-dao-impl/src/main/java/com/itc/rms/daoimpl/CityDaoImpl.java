package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.itc.rms.dao.CityDao;
import com.itc.rms.entities.City;


public  class CityDaoImpl  implements CityDao{
	
	@Autowired
	GenericRepository<City,Long> repo;

	@Override
	public boolean addCity(City city) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<City> getAllCity() {
		// TODO Auto-generated method stub
		return repo.getAll(City.class);
	}

}
