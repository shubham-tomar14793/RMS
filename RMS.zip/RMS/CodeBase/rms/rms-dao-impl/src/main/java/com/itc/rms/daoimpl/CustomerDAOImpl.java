package com.itc.rms.daoimpl;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.CustomerDao;
import com.itc.rms.entities.Customer;
import com.itc.rms.entities.User;
import com.itc.rms.utilities.JpaUtil;


/**
 * 
 * @author Saikat Dey Sarkar,Swati
 *
 */
@Repository("CustomerDao")
public class CustomerDAOImpl implements CustomerDao

{
	
	@Autowired
	GenericRepository<Customer,Long> repo=new GenericRepository<Customer, Long>();

	
	private EntityManagerFactory entityManagerFactory = null;

	public CustomerDAOImpl() {
		this.entityManagerFactory = JpaUtil.getEntityFactory();
	}
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addCustomer(Customer customer) {
		return repo.create(customer);
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Customer getCustomer(long customerId) {
		return repo.get(Customer.class,customerId);
	}

	@Override
	public User getCustomerByEmailId(String emailId) {
			javax.persistence.Entity entityAnn = (Entity) User.class.getAnnotation(javax.persistence.Entity.class);
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			Query query = entityManager.createQuery("select t from "+entityAnn.name()+" t "
					+ "where emailId='"+emailId+"'");
			
			return (User) query.getResultList().get(0);
	}
	
	
}


