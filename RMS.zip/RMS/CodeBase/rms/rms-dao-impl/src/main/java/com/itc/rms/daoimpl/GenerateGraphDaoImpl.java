package com.itc.rms.daoimpl;

/**
 * Akash Garg 20628
 */

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.itc.rms.dao.GenerateGraphDao;
import com.itc.rms.entities.Graph;
import com.itc.rms.utilities.JpaUtil;

@Repository
public class GenerateGraphDaoImpl implements GenerateGraphDao {
	private EntityManagerFactory entityManagerFactory = null;
	@Override
	
	/**
	 * From Database Requried data can be feteched by this method
	 */
	public List<Graph> getAllValueForGraph() {
		// TODO Auto-generated method stub
		
		entityManagerFactory=JpaUtil.getEntityFactory();
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		EntityTransaction tx = null;
		try {
			tx = entityManager.getTransaction();
			tx.begin();
			Query query=entityManager.createQuery("select r.retailer_name, o.order_date, sum(rp.quantity) from Retailer r, Order o, OrderItem oi, RetailerProduct rp,Product p where r.retailer_id=o.retailer_id and o.order_id=oi.order_id and oi.retailer_product_id=r.retailer_product_id");				//from Company where Company is name of class		//for retreiving multiple rows
			/*System.out.println("sdfbsdhfb");*/
			//Query query=entityManager.createQuery("select name from temp t where t.id=1");
			List<Graph> productList=query.getResultList();
			//System.out.println("Dao Impl");
			return productList;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}

}
