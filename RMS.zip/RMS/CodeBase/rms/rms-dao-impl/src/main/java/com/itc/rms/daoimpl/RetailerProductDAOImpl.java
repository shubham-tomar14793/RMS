package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.RetailerProductDAO;
import com.itc.rms.entities.RetailerProduct;

@Repository("RetailerProductDAO")
public class RetailerProductDAOImpl implements RetailerProductDAO{

	@Autowired
	GenericRepository<RetailerProduct,Long> repo;
	@Override
	public List<RetailerProduct> getAllRetailerProducts() {
		
		return repo.getAll(RetailerProduct.class);
	}
	@Override
	public boolean addRetailerProduct(RetailerProduct retailerProduct) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean deleteRetailerProduct(RetailerProduct retailerProduct) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean updateRetailerProduct(RetailerProduct retailerProduct) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
