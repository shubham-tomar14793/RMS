/**
 * 
 * @author Ranjitha
 *
 */

package com.itc.rms.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itc.rms.dao.AddressDao;
import com.itc.rms.entities.Address;
import com.itc.rms.utilities.JpaUtil;
/**
 * 
 * Implementation of AddressDAO
 *
 */

@Repository("AddressDAO")
public class AddressDAOImpl implements AddressDao {
	
	private EntityManagerFactory entityManagerFactory = null;

	public AddressDAOImpl() {
		this.entityManagerFactory = JpaUtil.getEntityFactory();
	}


		@Autowired
		GenericRepository<Address,Long> addressRepositry;

		/**
		 * 
		 * Method to get All Address
		 *
		 */
		
		
		@Override
		public List<Address> getAllAddress(long userId) {
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
		
			Query query = entityManager.createQuery("select a from Address a  where a.user.userId=:userId");
			
			query.setParameter("userId", userId);
			
			try
			{
				
				return query.getResultList();
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return null;
			}
		}
		
		/**
		 * 
		 * Method to add a new Address
		 *
		 */
		@Override
		public boolean addAddress(Address address,long userId) {
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			Query query = entityManager.createQuery("select count(*) from Address a  where a.user.userId=:userId");
			query.setParameter("userId", userId);
			
			int count= (int) query.getSingleResult();
			if(count<3)
				addressRepositry.create(address);
				return true;
				
		/*	}
			return false;*/
		}
		

		

		/**
		 * 
		 * Method to update a new Address
		 *
		 */
		
		@Override
		public boolean editAddress(Address address) {
			addressRepositry.update(address);
			return true;
		}
		

		/**
		 * 
		 * Method to delete a new Address
		 *
		 */
		@Override
		public boolean deleteAddress(Address address) {
			addressRepositry.remove(address);
			return false;
		}

		
		
	
}
