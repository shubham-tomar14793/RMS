package com.itc.rms.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.itc.rms.dao.SearchProductDao;
import com.itc.rms.entities.Product;

/**
 * 
 * @author Mohit Garg
 * Emp Id-20586
 *
 */

@Repository("SearchProductDAO")
public class SearchProductDaoImpl implements SearchProductDao {
	
	@Autowired
	GenericRepository<Product,Long> repo;
	/**
	 * Method to get all Products by name
	 * @return list of products
	 */
	@Override
	public List<Product> getProductByName(String productName)
	{	
		List<Product> productList=null;
		productList= repo.getAll(Product.class);
		
		for(Product product:productList)
		{
			if( !product.getProductName().equalsIgnoreCase(productName) )
			{
				productList.remove(product);
			}
		}
		
		return productList;
	}
	/**
	 * Method to get all Products by category
	 * @return list of products
	 */
	@Override
	public List<Product> getProductByCategory(String category) {
		// TODO Auto-generated method stub
		List<Product> productList=null;
		productList= repo.getAll(Product.class);
		
		for(Product product:productList)
		{
				if( !product.getCategory().getCategoryName().equalsIgnoreCase(category) )
				{
					productList.remove(product);
				}
		}
		
		return productList;
	}
	/**
	 * Method to get all Products by subCategory
	 * @return list of products
	 */
	@Override
	public List<Product> getProductBySubCategory(String subCategory) {
		// TODO Auto-generated method stub
		List<Product> productList=null;
		productList= repo.getAll(Product.class);
		
		for(Product product:productList)
		{
				if( !product.getSubCategory().getSubCategoryName().equalsIgnoreCase(subCategory) )
				{
					productList.remove(product);
				}
		}
		
		return productList;
	}
	
	public static void main(String[] args) {
		SearchProductDaoImpl impl = new SearchProductDaoImpl();
		System.out.println(impl.getProductByName("oil"));
	}
}


