package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.itc.rms.dao.OfferDao;
import com.itc.rms.entities.Offer;
import com.itc.rms.services.OfferServices;
/**
 * 
 * @author Devesh Rajput
 * EmpId 20594
 *
 */
public class OfferServiceImpl implements OfferServices{

	@Autowired
	OfferDao offerRepo;
	
	/**
	 * Method to get all Offers
	 * @return list of offers
	 */
	@Override
	public List<Offer> getAllOffers() {
	
		return offerRepo.getAllOffers();
	}
	/**
	 * Method to add Offer
	 * @param offer
	 * @return boolean
	 */
	@Override
	public boolean addOffer(Offer offer) {
		
		return offerRepo.addOffer(offer);
	}
	/**
	 * Method to update an offer
	 * @param offer
	 * @return boolean
	 */
	@Override
	public boolean updateOffer(Offer offer) {
		
		return offerRepo.updateOffer(offer);
	}
	/**
	 * Method to delete an offer
	 * @param offer
	 * @return boolean
	 */
	@Override
	public boolean deleteOffer(Offer offer) {
		
		return offerRepo.deleteOffer(offer);
	}
	/**
	 * Method to get all retailer Offers
	 * @param retailerId
	 * @return list of offers belonging to a retailer
	 */
	@Override
	public List<Offer> getAllRetailerOffers(long retailerId) {
		
		return offerRepo.getAllRetailerOffers(retailerId);
	}
	

}
