package com.itc.rms.serviceimpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.CustomerDao;
import com.itc.rms.daoimpl.CustomerDAOImpl;
import com.itc.rms.entities.Customer;
import com.itc.rms.entities.User;
import com.itc.rms.services.CustomerServices;

/**
 * 
 * @author swati,Saikat Dey Sarkar
 *
 */
@Service("CustomerServices")
public class CustomerServiceImpl implements CustomerServices {

	@Autowired
	CustomerDao customerRepo;
	@Override
	public boolean setCustomerDetails( Customer customer) {
		return customerRepo.addCustomer(customer);
	}
	@Override
	public Customer getCustomer(long customerId) {
		return customerRepo.getCustomer(customerId);
	}
	@Override
	public User getCustomerByEmailId(String emailId) {
		
		return customerRepo.getCustomerByEmailId(emailId);
	}
	

}