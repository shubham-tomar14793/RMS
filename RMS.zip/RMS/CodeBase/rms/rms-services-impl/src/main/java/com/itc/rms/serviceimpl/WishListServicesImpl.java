package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.SubCategoryDAO;
import com.itc.rms.dao.WishListDAO;
import com.itc.rms.entities.RetailerProduct;
import com.itc.rms.services.WishListServices;



@Service("WishListServices")
public class WishListServicesImpl implements WishListServices {
	
	@Autowired
	WishListDAO wishListRepository;

	@Override
	public List<RetailerProduct> getWishListByUserId(long userId) {
		return wishListRepository.getWishListByUserId(userId);
	}

	@Override
	public boolean addRetailerProduct(RetailerProduct retailerProduct, long userId) {
		return wishListRepository.addRetailerProduct(retailerProduct, userId);
	}
	
	@Override
	public boolean removeRetailerProduct(RetailerProduct retailerProduct, long userId) {
		return wishListRepository.removeRetailerProduct(retailerProduct, userId);
	}

}
