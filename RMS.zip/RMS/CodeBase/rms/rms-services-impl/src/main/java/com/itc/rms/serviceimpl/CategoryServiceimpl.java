package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.CategoryDAO;
import com.itc.rms.daoimpl.CategoryDAOImpl;
import com.itc.rms.entities.Category;
import com.itc.rms.services.CategoryServices;

/**
 * 
 * @author Abhishek Singh
 *
 */

@Service("CategoryServices")
public class CategoryServiceimpl implements CategoryServices{

	@Autowired
	CategoryDAO catRepo;
	
	public CategoryServiceimpl(){
		catRepo = new CategoryDAOImpl();
	}
	
	/**
	 * method to add category
	 */
	@Override
	public boolean addCategory(Category category){
		return catRepo.addCategory(category);
	}
	
	/**
	 * method to remove category
	 */
	@Override
	public boolean removeCategory(Category category) {
		if(catRepo.removeCategory(category)==true)
		return true;
		
		else return false;
	}
	
	/**
	 * method to edit category
	 */
	@Override
	public boolean editCategory(Category category) {
		if(catRepo.editCategory(category)==true)
		return true;
		
		else return false;
	}
	
	/**
	 * method to view category
	 */
	@Override
	public List<Category> viewCategory() {
		return catRepo.viewCategory();
		
	}

}
