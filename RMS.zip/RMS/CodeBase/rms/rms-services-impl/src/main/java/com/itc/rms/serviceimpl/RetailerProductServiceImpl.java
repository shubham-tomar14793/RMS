package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.RetailerProductDAO;
import com.itc.rms.entities.Product;
import com.itc.rms.entities.RetailerProduct;
import com.itc.rms.services.RetailerProductServices;

@Service("RetailerProductServices")
public class RetailerProductServiceImpl implements RetailerProductServices {

	@Autowired
	RetailerProductDAO productRepo;
	@Override
	public List<RetailerProduct> getAllProducts() {
		return productRepo.getAllRetailerProducts();
	}

}
