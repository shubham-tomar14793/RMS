package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.OrderAddressDAO;
import com.itc.rms.entities.OrderAddress;
import com.itc.rms.services.OrderAddressService;
@Service
public class OrderAddressServiceImpl implements OrderAddressService{

	@Autowired
	OrderAddressDAO orderAddressDao;
	
	@Override
	public boolean addOrderAddress(OrderAddress orderAddress) {
		return orderAddressDao.addOrderAddress(orderAddress);
	}

	@Override
	public OrderAddress getOrderAddress(Long order_Address_Id) {
		return orderAddressDao.getOrderAddress(order_Address_Id);
	}

	@Override
	public List<OrderAddress> getOrderAddress() {
		return orderAddressDao.getOrderAddress();
	}

}
