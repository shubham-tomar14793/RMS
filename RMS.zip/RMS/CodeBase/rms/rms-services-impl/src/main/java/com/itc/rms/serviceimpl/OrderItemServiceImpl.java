package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.OrderItemDAO;
import com.itc.rms.entities.OrderItem;
import com.itc.rms.services.OrderItemService;
@Service
public class OrderItemServiceImpl implements OrderItemService{

	@Autowired
	OrderItemDAO orderItemDao;
	
	@Override
	public List<OrderItem> getOrderItem() {
		return orderItemDao.getOrderItem();
	}

	@Override
	public OrderItem getOrderItem(Long order_Id) {
		
		return orderItemDao.getOrderItem(order_Id);
	}

	@Override
	public boolean addOrderItem(OrderItem orderItem) {
		return orderItemDao.addOrderItem(orderItem);
	}

	@Override
	public boolean removeOrderItem(OrderItem orderItem) {
	  return orderItemDao.removeOrderItem(orderItem);
		
	}
	

}
