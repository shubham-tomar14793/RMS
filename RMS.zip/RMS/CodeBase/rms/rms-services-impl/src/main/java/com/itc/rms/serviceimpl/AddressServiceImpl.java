package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.AddressDao;
import com.itc.rms.entities.Address;
import com.itc.rms.services.AddressServices;

@Service("AddressServices")
public class AddressServiceImpl implements AddressServices{

	@Autowired
	AddressDao addressDAO;

	@Override
	public List<Address> getAllAddress(long userId) {
		
		return addressDAO.getAllAddress(userId);
	}

	@Override
	public boolean addAddress(Address address,long userId) {
		addressDAO.addAddress(address,userId);
		return true;
	}

	@Override
	public boolean editAddress(Address address) {
		addressDAO.editAddress(address);
		return true;
	}

	@Override
	public boolean deleteAddress(Address address) {
		addressDAO.deleteAddress(address);
		return true;
	}
	
}
