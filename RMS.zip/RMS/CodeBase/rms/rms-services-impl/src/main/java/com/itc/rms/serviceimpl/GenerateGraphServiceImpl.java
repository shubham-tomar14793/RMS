package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.GenerateGraphDao;
import com.itc.rms.daoimpl.GenerateGraphDaoImpl;
import com.itc.rms.entities.Graph;
import com.itc.rms.services.GenerateGraphServices;


/**
 * Akash Garg 20628
 */



@Service("GenerateGraphServices")
public class GenerateGraphServiceImpl implements GenerateGraphServices {

	@Autowired
	GenerateGraphDao generateGraph;

	
	/*//To test Method
	public GenerateGraphServiceImpl() {
		// TODO Auto-generated constructor stub
		generateGraph=new GenerateGraphDaoImpl();
	}*/
	
	@Override
	public List<Graph> getAllValueForGraph() {
		// TODO Auto-generated method stub
		//System.out.println("Service Impl");
		//System.out.println("sdfjks");
		return generateGraph.getAllValueForGraph();
	}
}
