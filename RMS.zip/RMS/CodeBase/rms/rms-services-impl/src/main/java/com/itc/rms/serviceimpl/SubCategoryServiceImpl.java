package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.SubCategoryDAO;
import com.itc.rms.entities.Category;
import com.itc.rms.entities.SubCategory;
import com.itc.rms.services.SubCategoryServices;

/**
 * 
 * @author Karan(20564)
 *
 */
@Service("SubCategoryServices")
public class SubCategoryServiceImpl implements SubCategoryServices{

	@Autowired
	SubCategoryDAO subCategoryRepository;
	
	@Override
	public boolean createSubCategory(SubCategory subCategory) {
		return subCategoryRepository.createSubCategory(subCategory);
	}

	@Override
	public boolean removeSubCategory(SubCategory subCategory) {
		return subCategoryRepository.removeSubCategory(subCategory);
	}

	@Override
	public boolean updateSubCategory(SubCategory subCategory) {
		return subCategoryRepository.updateSubCategory(subCategory);
	}

	@Override
	public List<SubCategory> getAllSubCategories() {
		return subCategoryRepository.getAllSubCategories();
	}

	@Override
	public List<SubCategory> getSubCategoriesByCategory(Category category) {
		return subCategoryRepository.getSubCategoriesByCategory(category);
	}

}
