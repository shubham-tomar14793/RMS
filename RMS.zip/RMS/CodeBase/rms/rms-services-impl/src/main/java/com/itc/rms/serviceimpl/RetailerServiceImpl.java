/**
 * @Author: Prasoon Mehta (20588)
 * @author DEBANJAN SEN (20573)
 */
package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.RetailerDAO;
import com.itc.rms.daoimpl.RetailerDAOImpl;
import com.itc.rms.entities.Retailer;
import com.itc.rms.services.RetailerServices;



@Service("RetailerServices")
public class RetailerServiceImpl implements RetailerServices{

	@Autowired 
	RetailerDAO retailerRepo;

	/**
	 * direct added retailer object to DAO layer 
	 */
	@Override
	public boolean addRetailer(Retailer retailer) {
		return retailerRepo.addRetailer(retailer);
	}


	/**
	 * direct retailer object to be removed to DAO layer 
	 */
	
	@Override
	public boolean removeRetailer(Retailer retailer) {
		return retailerRepo.removeRetailer(retailer);
	}

	/**
	 * direct retailer object to be edited to DAO layer 
	 */ 
	
	@Override
	public boolean editRetailer(Retailer retailer) {
		return retailerRepo.editRetailer(retailer);
	}
	
	/**
	 * direct to DAO layer for viewing all retailers
	 */ 
	
	@Override
	public List<Retailer> viewAllRetailer() {
		return retailerRepo.getAllRetailer();
	}

	
	
	
}
