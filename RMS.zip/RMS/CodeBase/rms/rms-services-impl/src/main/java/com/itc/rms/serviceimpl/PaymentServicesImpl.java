package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.PaymentDAO;
import com.itc.rms.daoimpl.PaymentDAOImpl;
import com.itc.rms.entities.Order;
import com.itc.rms.entities.Payment;
import com.itc.rms.services.PaymentServices;

@Service
public  class PaymentServicesImpl implements PaymentServices {
	
	

	public PaymentServicesImpl() {
		super();
	}


	@Autowired
	PaymentDAO paymentRepository;

	@Override
	public boolean addPaymentDetails(Payment payment) {
		if(paymentRepository.addPaymentDetails(payment))
		return true;
		
		return false;
	}


	@Override
	public List<Payment> getPaymentDetails() {
		return paymentRepository.getPaymentDeatils();
	}


	@Override
	public Payment getPaymentDetailsByOrder(Order order) {
		return paymentRepository.getPaymentDetailsByOrder(order);
	}

	
	

	

}
