package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.SearchProductDao;
import com.itc.rms.entities.Product;
import com.itc.rms.services.SearchProductServices;
/**
 * 
 * @author Mohit Garg
 *Emp id-20586
 */
@Service
public class SearchProductServiceImpl implements SearchProductServices {
	
	@Autowired
	SearchProductDao searchDao;
	
	/**
	 * Method to get all Products by name
	 * @return list of products
	 */
	@Override
	public List<Product> getProductByName(String productName) {
		// TODO Auto-generated method stub
		return searchDao.getProductByName(productName);
	}

	/**
	 * Method to get all Products by category
	 * @return list of products
	 */
	@Override
	public List<Product> getProductByCategory(String category) {
		// TODO Auto-generated method stub
		return searchDao.getProductByCategory(category);
	}

	/**
	 * Method to get all Products by subCategory
	 * @return list of products
	 */
	@Override
	public List<Product> getProductBySubCategory(String subCategory) {
		// TODO Auto-generated method stub
		return searchDao.getProductBySubCategory(subCategory);
	}

}
