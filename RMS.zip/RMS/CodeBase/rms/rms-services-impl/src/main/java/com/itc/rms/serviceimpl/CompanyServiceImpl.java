package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.CompanyDao;
import com.itc.rms.entities.Company;
import com.itc.rms.services.CompanyServices;
@Service
public class CompanyServiceImpl implements CompanyServices {

	@Autowired
	CompanyDao companydao;
	@Override
	public boolean addCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean editCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Company> getAllCompany() {
		// TODO Auto-generated method stub
		return companydao.getAllCompany();
	}

}
