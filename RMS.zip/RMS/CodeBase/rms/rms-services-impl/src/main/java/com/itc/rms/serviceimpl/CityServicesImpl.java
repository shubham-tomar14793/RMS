package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.daoimpl.GenericRepository;
import com.itc.rms.entities.City;


import com.itc.rms.services.CityServices;

@Service
public class CityServicesImpl implements CityServices {

	@Autowired
	GenericRepository<City,Long> repo;
	@Override
	public boolean addCity(City city) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<City> getAllCity() {
		// TODO Auto-generated method stub
		return repo.getAll(City.class);
	}

}
