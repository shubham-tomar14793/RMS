package com.itc.rms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itc.rms.dao.HomePageDao;
import com.itc.rms.daoimpl.HomePageDaoImpl;
import com.itc.rms.entities.RetailerProduct;
import com.itc.rms.services.HomeServices;
/**
 * 
 * @author shubham
 *
 */

@Service("HomeServices")
public class HomeServicesImpl implements HomeServices {
	@Autowired
	HomePageDao homePageDao;	
	@Override
	public List<RetailerProduct> getAllRetailerProduct() {
		System.out.println("HomeServicesImpl");
         return homePageDao.getAllRetailerProduct();
	}

}
