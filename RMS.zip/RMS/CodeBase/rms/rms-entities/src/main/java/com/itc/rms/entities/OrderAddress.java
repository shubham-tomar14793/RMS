package com.itc.rms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 
 * @author Anushka
 *
 */

@Entity(name="OrderAddress")
@Table(name="order_address")
public class OrderAddress {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="order_address_id")
	private long orderAddressId;
	
	private String address;
	

	public long getOrderAddressId() {
		return orderAddressId;
	}

	public void setOrderAddressId(long orderAddressId) {
		this.orderAddressId = orderAddressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "OrderAddress [orderAddressId=" + orderAddressId + ", address="
				+ address + "]";
	}

	
}
