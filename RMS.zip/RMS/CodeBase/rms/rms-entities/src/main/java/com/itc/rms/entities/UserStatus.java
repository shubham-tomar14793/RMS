package com.itc.rms.entities;

public enum UserStatus {
	TRUE,FALSE;

}
