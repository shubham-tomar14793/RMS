package com.itc.rms.entities;

/**
 * 
 * @author Sourav Sinha
 *
 */
public enum Role {
	CUSTOMER,ADMIN,RETAILER

}
