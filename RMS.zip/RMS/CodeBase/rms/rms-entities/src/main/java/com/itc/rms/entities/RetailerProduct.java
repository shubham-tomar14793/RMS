package com.itc.rms.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Transient;

@Entity(name="RetailerProduct")
@PrimaryKeyJoinColumn(name="productID")  
public class RetailerProduct extends Product {

	@Column(name="price")
	private double price;
	//
	private int quantity;
	
	@ManyToOne
	@JoinColumn(name="retailer_id")
	private Retailer retailer;
	
	@ManyToOne
	@JoinColumn(name="offer_id")
	private Offer discount;
	
	@Transient
	@ManyToMany
	@JoinTable
	private List<WishList> wishLists;
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Offer getDiscount() {
		return discount;
	}
	public void setDiscount(Offer discount) {
		this.discount = discount;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Retailer getRetailer() {
		return retailer;
	}
	public void setRetailer(Retailer retailer) {
		this.retailer = retailer;
	}
	@Override
	public String toString() {
		return "RetailerProduct [retailerProductId="+retailer.getUserId()+", price=" + price + ", discount=" + discount.getDiscount()
				+ "]";
	}
	
	
}
