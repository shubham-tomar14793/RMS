package com.itc.rms.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 
 * @author root
 *
 */
@Entity(name="WishList")
@Table(name="wishList")
public class WishList {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="wish_list_id")
	private long wishListId;
	
	@OneToOne
	@JoinColumn(name="user_id")
	private Customer customer;
	
	
	@Transient
	@ManyToMany(mappedBy="wishLists") 
	private List<RetailerProduct> retailerProduct;
	
	public long getWishListId() {
		return wishListId;
	}
	public void setWishListId(long wishListId) {
		this.wishListId = wishListId;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<RetailerProduct> getRetailerProduct() {
		return retailerProduct;
	}
	public void setRetailerProduct(List<RetailerProduct> retailerProduct) {
		this.retailerProduct = retailerProduct;
	}
		
	/*@Override
	public String toString() {
		
		return "wish list id: "+wishListId+"user id: "+user.getUserId()+"user name: "+user.getFirstName();
	}*/
}
