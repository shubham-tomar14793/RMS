package com.itc.rms.entities;

public enum Measure {
	KG,GM,LITER,ML,PIECE,DOZEN
}
