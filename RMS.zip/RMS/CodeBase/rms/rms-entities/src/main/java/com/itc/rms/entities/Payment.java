package com.itc.rms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 
 * @author Debolina
 *
 */

@Entity(name="Payment")
@Table(name="payment")
public class Payment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="payment_id")
	private long paymentId;
	@Column(name="card_type")
	private String cardType;
	@Column(name="card_number")
	private double cardNumber;
	@Column(name="cvv_no")
	private int CVVNo;
	@Column(name="name_oncard")
	private String NameOnCard;
	
	@OneToOne
	@JoinColumn(name="order_id")
	private Order order;
	
	
	
	public void setOrder(Order order) {
		this.order = order;
	}
	
	public long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public double getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(double cardNumber) {
		this.cardNumber = cardNumber;
	}
	public int getCVVNo() {
		return CVVNo;
	}
	public void setCVVNo(int cVVNo) {
		CVVNo = cVVNo;
	}
	public String getNameOnCard() {
		return NameOnCard;
	}
	public void setNameOnCard(String nameOnCard) {
		NameOnCard = nameOnCard;
	}
	
	public Order getOrder() {
		return order;
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", cardType=" + cardType + ", cardNumber=" + cardNumber + ", CVVNo="
				+ CVVNo + ", NameOnCard=" + NameOnCard + ", order=" + order + "]";
	}
	
	
}
	
	
	