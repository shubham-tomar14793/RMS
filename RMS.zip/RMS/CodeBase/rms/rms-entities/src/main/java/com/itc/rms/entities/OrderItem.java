package com.itc.rms.entities;


import com.itc.rms.entities.RetailerProduct;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 
 * @author Anushka
 *
 */

@Entity(name="OrderItem")
@Table(name="order_item")
public class OrderItem{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="order_item_id")
	private long orderItemId;
	
	@OneToOne
	@JoinColumn(name="retailer_product")
	private RetailerProduct retailerProduct;
	
	@Column(name="quantity")
	private int quantity;
	
	@ManyToOne
	@JoinColumn(name="order_id")
	private Order order;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public RetailerProduct getRetailerProduct() {
		return retailerProduct;
	}

	public void setRetailerProduct(RetailerProduct retailerProduct) {
		this.retailerProduct = retailerProduct;
	}

	public long getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(long orderItemId) {
		this.orderItemId = orderItemId;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "OrderItem [orderItemId=" + orderItemId + ", retailerProduct="
				+ retailerProduct + ", quantity=" + quantity + ", order="
				+ order + "]";
	}
	
	

}
