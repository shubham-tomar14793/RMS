package com.itc.rms.entities;

public enum OrderStatus {
	CONFIRMED,DISPATCHED,DELIVERED;
	//to-do
}
