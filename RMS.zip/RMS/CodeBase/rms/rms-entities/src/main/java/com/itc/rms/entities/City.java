/**
 * AUTHOR: Ranjitha
 */
package com.itc.rms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity(name="City")
@Table(name="city")
public class City {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long cityId;
	private String cityName;
	@ManyToOne
	@JoinColumn(name="state_id",insertable=true,
	        updatable=true,nullable=true,unique=true)
	private State state;
	
	public long getCityId() {
		return cityId;
	}
	public void setCityId(long cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public State getState() {
		return state;
	}
	public void setState(State state) {
		this.state = state;
	}
	
	
}
