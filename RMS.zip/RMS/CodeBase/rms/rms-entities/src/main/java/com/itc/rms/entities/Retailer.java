package com.itc.rms.entities;

import java.util.List;

import javax.persistence.*;


@Entity(name="Retailer")
@Table(name="retailer")
@PrimaryKeyJoinColumn(name="userID")  
public class Retailer extends User {
	@Transient
	@OneToMany(mappedBy="retailer", cascade=CascadeType.ALL)
	private List<RetailerProduct> retailerProducts;
	
	
	@Column(name="retailer_name")
	private String retailerName;
	
	

	public List<RetailerProduct> getRetailerProducts() {
		return retailerProducts;
	}


	public void setRetailerProducts(List<RetailerProduct> retailerProducts) {
		this.retailerProducts = retailerProducts;
	}


	public String getRetailerName() {
		return retailerName;
	}


	public void setRetailerName(String retailerName) {
		this.retailerName = retailerName;
	}


	
	
}
