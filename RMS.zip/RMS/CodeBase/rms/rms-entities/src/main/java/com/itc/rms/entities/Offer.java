package com.itc.rms.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 
 * @author Devesh Rajput
 *
 */

@Entity(name = "Offer")
@Table(name = "Offer")
public class Offer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long offerId;
	@Column(name = "OFFER_NAME" , nullable = false)//
	private String offerName;
	@Column(name = "DISCOUNT" , nullable = false)//
	private double discount;
	
	@ManyToOne
	@JoinColumn(name = "retailerId")
	@Transient
	private Retailer retailer;
	@Transient
	@OneToMany(mappedBy="discount",cascade=CascadeType.ALL)
	private List<RetailerProduct> retailerProducts;
	
	public Offer() {
		super();
	}
	public Offer(long offerId, double discount
			,String offerName) {
		super();
		this.offerId = offerId;
		this.offerName = offerName;
		this.discount = discount;
		
	}
	public long getOfferId() {
		return offerId;
	}
	public void setOfferId(long offerId) {
		this.offerId = offerId;
	}
	public String getOfferName() {
		return offerName;
	}
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public Retailer getRetailer() {
		return retailer;
	}
	public void setRetailer(Retailer retailer) {
		this.retailer = retailer;
	}
	public List<RetailerProduct> getRetailerProducts() {
		return retailerProducts;
	}
	public void setRetailerProducts(List<RetailerProduct> retailerProducts) {
		this.retailerProducts = retailerProducts;
	}
	@Override
	public String toString(){
		return "Offer [ offerName="+offerName+" , offerId="+offerId+" , offerDiscount="+discount+" , retailerId="+retailer+"]";
	}
	
		
}
