/**
 * AUTHOR: Ranjitha
 */
package com.itc.rms.entities;

	import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

	@Entity(name="Address")
	@Table(name="address")
	public class Address{

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name="address_Id")
		private long addressId;
		@Column(name="full_Name")
		private String fullName;
		@Column(name="street_Address")
		private String streetAddress;
		@Column(name="landmark")
		private String landMark;
		
		@OneToOne
		@JoinColumn(name="city_id",insertable=true,
		        updatable=true,nullable=true,unique=true)
		private City city;
		@OneToOne
		@JoinColumn(name="state_id",insertable=true,
		        updatable=true,nullable=true,unique=true)
		private State state;
		@Column(name="pin_Code")
		private int pinCode;
		@Column(name="phone_Number")
		private long phoneNumber;
		@Column(name="isDefault")
		private boolean isDefault;
		
		@ManyToOne
		@JoinColumn(name="user_id")
		private User user;
		
		public long getAddressId() {
			return addressId;
		}
		public void setAddressId(long addressId) {
			this.addressId = addressId;
		}
		public String getFullName() {
			return fullName;
		}
		public void setFullName(String fullName) {
			this.fullName = fullName;
		}
		public String getStreetAddress() {
			return streetAddress;
		}
		public void setStreetAddress(String streetAddress) {
			this.streetAddress = streetAddress;
		}
		public String getLandMark() {
			return landMark;
		}
		public void setLandMark(String landMark) {
			this.landMark = landMark;
		}
		public City getCity() {
			return city;
		}
		public void setCity(City city) {
			this.city = city;
		}
		public State getState() {
			return state;
		}
		public void setState(State state) {
			this.state = state;
		}
		public int getPinCode() {
			return pinCode;
		}
		public void setPinCode(int pinCode) {
			this.pinCode = pinCode;
		}
		public long getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public boolean isDefault() {
			return isDefault;
		}
		public void setDefault(boolean isDefault) {
			this.isDefault = isDefault;
		}
		
		public User getUser() {
			return user;
		}
		public void setUser(User user) {
			this.user = user;
		}
		
		@Override
		public String toString() {
			return "Address [addressId=" + addressId + ", fullName=" + fullName + ", streetAddress=" + streetAddress
					+ ", landMark=" + landMark + ", city=" + city + ", state=" + state + ", pinCode=" + pinCode
					+ ", phoneNumber=" + phoneNumber + "]";
		}
		
		
}
