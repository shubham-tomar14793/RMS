package com.itc.rms.entities;

import java.util.Date;
import java.util.List;

public class Graph {

	private String retailer_name;
	private Date order_date;
	private int noOfProduct;
	public String getRetailer_name() {
		return retailer_name;
	}
	public void setRetailer_name(String retailer_name) {
		this.retailer_name = retailer_name;
	}
	public Date getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}
	public int getNoOfProduct() {
		return noOfProduct;
	}
	public void setNoOfProduct(int noOfProduct) {
		this.noOfProduct = noOfProduct;
	}
	
	
	
}
