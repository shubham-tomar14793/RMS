package com.itc.rms.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity(name="Customer")
@Table(name="customer")
@PrimaryKeyJoinColumn(name="userID")  
public class Customer extends User{

	@OneToOne
	@JoinColumn(name="wish_list_id")
	private WishList wishLists;
	
	@OneToMany(mappedBy="orderId",cascade = CascadeType.ALL)
	@JoinColumn(name="order_id")
	private List<Order> orders;

	public WishList getWishLists() {
		return wishLists;
	}

	public void setWishLists(WishList wishLists) {
		this.wishLists = wishLists;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}
